
###############
# Housekeeping
###############

# get working directory
getwd()
#[1] "/Users/debasmitamohanty/UT-R-Projects/C4T1"
# set working directory
setwd("/Users/debasmitamohanty/UT-R-Projects/C4T1")
dir()


################
# Load packages
################
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("RMySQL")
install.packages("dplyr")
#install.packages("dbConnect")
install.packages("lubridate")
install.packages("ggfortify")
install.packages("plotly")
install.packages("forecast")
install.packages("DBI")
library(dplyr)
library(RMySQL)
library(dbConnect)
library(lubridate)
library(ggplot2)
library(plotly)
library(ggfortify)
library(forecast)
library(tidyverse)

##############
# Import data
##############

##--- Load raw datasets ---##

# Load Train/Existing data (Dataset 1)

# Read a txt file
oob_hpc <- read.csv("household_power_consumption.txt", stringsAsFactors = FALSE, header=T)



## Create a database connection 
con = dbConnect(MySQL(), user='deepAnalytics', password='Sqltask1234!',
                dbname='dataanalytics2018', host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')


## List the tables contained in the database 
dbListTables(con)
##[1] "iris"    "yr_2006" "yr_2007" "yr_2008" "yr_2009" "yr_2010"

## Use asterisk to specify all attributes for download
irisALL <- dbGetQuery(con, "SELECT * FROM iris")
#Warning message:
 # In .local(conn, statement, ...) :
 # Unsigned INTEGER in col 0 imported as numeric
str(irisALL)

#Downloading all attributes for all years
yr_2006 <- dbGetQuery(con, "SELECT * FROM yr_2006")
yr_2007 <- dbGetQuery(con, "SELECT * FROM yr_2007") 
yr_2008 <- dbGetQuery(con, "SELECT * FROM yr_2008") 
yr_2009 <- dbGetQuery(con, "SELECT * FROM yr_2009") 
yr_2010 <- dbGetQuery(con, "SELECT * FROM yr_2010")
#Warning message:
# In .local(conn, statement, ...) :
#Unsigned INTEGER in col 0 imported as numeric

dbListFields(con,'yr_2006 ')
#dbListFields(con,'yr_2006 ')
#[1] "id"                    "Date"                  "Time"                  "Global_active_power"  
#[5] "Global_reactive_power" "Global_intensity"      "Voltage"               "Sub_metering_1"       
#[9] "Sub_metering_2"        "Sub_metering_3"  


attributes(yr_2006)
View(yr_2006)

summary(yr_2006)
#Date               Time           Global_active_power Sub_metering_1   Sub_metering_2   Sub_metering_3 
#Length:21992       Length:21992       Min.   :0.194       Min.   : 0.000   Min.   : 0.000   Min.   : 0.00  
#Class :character   Class :character   1st Qu.:0.496       1st Qu.: 0.000   1st Qu.: 0.000   1st Qu.: 0.00  
#Mode  :character   Mode  :character   Median :1.708       Median : 0.000   Median : 0.000   Median : 0.00  
#Mean   :1.901       Mean   : 1.249   Mean   : 2.215   Mean   : 7.41  
#3rd Qu.:2.692       3rd Qu.: 0.000   3rd Qu.: 1.000   3rd Qu.:17.00  
#Max.   :9.132       Max.   :77.000   Max.   :74.000   Max.   :20.00  



str(yr_2006)
#str(yr_2006)
#'data.frame':	21992 obs. of  6 variables:
#  $ Date               : chr  "2006-12-16" "2006-12-16" "2006-12-16" "2006-12-16" ...
#$ Time               : chr  "17:24:00" "17:25:00" "17:26:00" "17:27:00" ...
#$ Global_active_power: num  4.22 5.36 5.37 5.39 3.67 ...
#$ Sub_metering_1     : num  0 0 0 0 0 0 0 0 0 0 ...
#$ Sub_metering_2     : num  1 1 2 1 1 2 1 1 1 2 ...
#$ Sub_metering_3     : num  17 16 17 17 17 17 17 17 17 16 ...



head(yr_2006)
#Date     Time Global_active_power Sub_metering_1 Sub_metering_2 Sub_metering_3
#1 2006-12-16 17:24:00               4.216              0              1             17
#2 2006-12-16 17:25:00               5.360              0              1             16
#3 2006-12-16 17:26:00               5.374              0              2             17
#4 2006-12-16 17:27:00               5.388              0              1             17
#5 2006-12-16 17:28:00               3.666              0              1             17
#6 2006-12-16 17:29:00               3.520              0              2             17

tail(yr_2006)
#Date     Time Global_active_power Sub_metering_1 Sub_metering_2 Sub_metering_3
#21987 2006-12-31 23:54:00               2.576              0              0              0
#21988 2006-12-31 23:55:00               2.574              0              0              0
#21989 2006-12-31 23:56:00               2.576              0              0              0
#21990 2006-12-31 23:57:00               2.586              0              0              0
#21991 2006-12-31 23:58:00               2.648              0              0              0
#21992 2006-12-31 23:59:00               2.646              0              0              0


head(yr_2007)

#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#1 2007-01-01 00:00:00              0              0              0
#2 2007-01-01 00:01:00              0              0              0
#3 2007-01-01 00:02:00              0              0              0
#4 2007-01-01 00:03:00              0              0              0
#5 2007-01-01 00:04:00              0              0              0
#6 2007-01-01 00:05:00              0              0              0

tail(yr_2007)

#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#521664 2007-12-31 23:54:00              0              0             18
#521665 2007-12-31 23:55:00              0              0             18
#521666 2007-12-31 23:56:00              0              0             18
#521667 2007-12-31 23:57:00              0              0             18
#521668 2007-12-31 23:58:00              0              0             18
#521669 2007-12-31 23:59:00              0              0             18

### (yr_2007)contains 1 full year

head(yr_2008)
#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#1 2008-01-01 00:00:00              0              0             18
#2 2008-01-01 00:01:00              0              0             18
#3 2008-01-01 00:02:00              0              0             18
#4 2008-01-01 00:03:00              0              0             18
#5 2008-01-01 00:04:00              0              0             18
#6 2008-01-01 00:05:00              0              0             17

tail(yr_2008)
#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#526900 2008-12-31 23:54:00              0              0              0
#526901 2008-12-31 23:55:00              0              0              0
#526902 2008-12-31 23:56:00              0              0              0
#526903 2008-12-31 23:57:00              0              0              0
#526904 2008-12-31 23:58:00              0              0              0
#526905 2008-12-31 23:59:00              0              0              0

##(yr_2008) contains 1 full year

head(yr_2009)
#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#1 2009-01-01 00:00:00              0              0              0
#2 2009-01-01 00:01:00              0              0              0
#3 2009-01-01 00:02:00              0              0              0
#4 2009-01-01 00:03:00              0              0              0
#5 2009-01-01 00:04:00              0              0              0
#6 2009-01-01 00:05:00              0              0              0

tail(yr_2009)

#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#521315 2009-12-31 23:54:00              0              0             18
#521316 2009-12-31 23:55:00              0              0             18
#521317 2009-12-31 23:56:00              0              0             19
#521318 2009-12-31 23:57:00              0              0             18
#521319 2009-12-31 23:58:00              0              0             18
#521320 2009-12-31 23:59:00              0              0             19

###(yr_2009)contains 1 full year


head(yr_2010)

#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#1 2010-01-01 00:00:00              0              0             18
#2 2010-01-01 00:01:00              0              0             18
#3 2010-01-01 00:02:00              0              0             19
#4 2010-01-01 00:03:00              0              0             18
#5 2010-01-01 00:04:00              0              0             18
#6 2010-01-01 00:05:00              0              0             19

tail(yr_2010)
#Date     Time Sub_metering_1 Sub_metering_2 Sub_metering_3
#457389 2010-11-26 20:57:00              0              0              0
#457390 2010-11-26 20:58:00              0              0              0
#457391 2010-11-26 20:59:00              0              0              0
#457392 2010-11-26 21:00:00              0              0              0
#457393 2010-11-26 21:01:00              0              0              0
#457394 2010-11-26 21:02:00              0              0              0


##(yr_2010) # contains 11 months


#Refine attributes needed
yr_2006 <- select(yr_2006, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3)
yr_2007 <- select(yr_2007, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3)
yr_2008 <- select(yr_2008, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3) 
yr_2009 <- select(yr_2009, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3)
yr_2010 <- select(yr_2010, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3) 

final <- bind_rows(yr_2006, yr_2007, yr_2008, yr_2009, yr_2010)

#Combine date & time
final <- cbind(final, paste(final$Date, final$Time), stringsAsFactors = FALSE)
#Change col name
colnames(final)[7] <- "DateTime"

final <- final[,c(ncol(final), 1:(ncol(final)-1))]
## Convert DateTime from character to POSIXct 
final$DateTime <- as.POSIXct(final$DateTime, "%Y/%m/%d %H:%M:%S")
#Warning messages:
#  1: In strptime(xx, f, tz = tz) : unknown timezone '%Y/%m/%d %H:%M:%S'
#2: In as.POSIXct.POSIXlt(x) : unknown timezone '%Y/%m/%d %H:%M:%S'
#3: In strptime(x, f, tz = tz) : unknown timezone '%Y/%m/%d %H:%M:%S'
#4: In as.POSIXct.POSIXlt(as.POSIXlt(x, tz, ...), tz, ...) :
# unknown timezone '%Y/%m/%d %H:%M:%S'

## Add the time zone
attr(final$DateTime, "tzone") <- "Europe/Paris"

##Extract "Year" information from DateTime using the Lubridate "year" function and create an attribute for year

###Lubridate###
##Create year 
final$Year <- year(final$DateTime)
#Create rest of time frames
final$Quarter <- quarter(final$DateTime)
final$Month <- month(final$DateTime)
final$Week <- week(final$DateTime)
final$Weekdays <- weekdays(final$DateTime)
final$Day <- day(final$DateTime)
final$Hour <- hour(final$DateTime)
final$Minute <- minute(final$DateTime)

colnames(final)[4] <- "Household.Power(kW)"
colnames(final)[5] <- "Kitchen(Wh)" 
colnames(final)[6] <- "Laundry.Room(Wh)" 
colnames(final)[7] <- "Heater.&.A/C(Wh)"

#Remove unneeded
final[,c(2,3)] <- NULL

head(final)
#head(final)
#DateTime Laundry.Room(Wh) Heater.&.A/C(Wh) Year Quarter Month Week Weekdays Day Hour Minute
#1 2006-12-16 18:24:00                1               17 2006       4    12   50 Saturday  16   18     24
#2 2006-12-16 18:25:00                1               16 2006       4    12   50 Saturday  16   18     25
#3 2006-12-16 18:26:00                2               17 2006       4    12   50 Saturday  16   18     26
#4 2006-12-16 18:27:00                1               17 2006       4    12   50 Saturday  16   18     27
#5 2006-12-16 18:28:00                1               17 2006       4    12   50 Saturday  16   18     28
#6 2006-12-16 18:29:00                2               17 2006       4    12   50 Saturday  16   18     29

str(final)
#'data.frame':	2049280 obs. of  11 variables:
# $ DateTime        : POSIXct, format: "2006-12-16 18:24:00" "2006-12-16 18:25:00" "2006-12-16 18:26:00" "2006-12-16 18:27:00" ...
#$ Laundry.Room(Wh): num  1 1 2 1 1 2 1 1 1 2 ...
#$ Heater.&.A/C(Wh): num  17 16 17 17 17 17 17 17 17 16 ...
#$ Year            : num  2006 2006 2006 2006 2006 ...
#$ Quarter         : int  4 4 4 4 4 4 4 4 4 4 ...
#$ Month           : num  12 12 12 12 12 12 12 12 12 12 ...
#$ Week            : num  50 50 50 50 50 50 50 50 50 50 ...
#$ Weekdays        : chr  "Saturday" "Saturday" "Saturday" "Saturday" ...
#$ Day             : int  16 16 16 16 16 16 16 16 16 16 ...
#$ Hour            : int  18 18 18 18 18 18 18 18 18 18 ...
#$ Minute          : int  24 25 26 27 28 29 30 31 32 33 ...

#Check for missing values 
sum(is.na(final))
#[1] 0

summary(final)
#> summary(final)
#DateTime                   Household.Power(kW)  Kitchen(Wh)     Laundry.Room(Wh) Heater.&.A/C(Wh)
#Min.   :2006-12-16 18:24:00   Min.   : 0.076      Min.   : 0.000   Min.   : 0.000   Min.   : 0.000  
#1st Qu.:2007-12-10 06:37:45   1st Qu.: 0.308      1st Qu.: 0.000   1st Qu.: 0.000   1st Qu.: 0.000  
#Median :2008-11-30 02:22:30   Median : 0.602      Median : 0.000   Median : 0.000   Median : 1.000  
#Mean   :2008-12-02 01:59:44   Mean   : 1.092      Mean   : 1.122   Mean   : 1.299   Mean   : 6.458  
#3rd Qu.:2009-11-23 21:31:15   3rd Qu.: 1.528      3rd Qu.: 0.000   3rd Qu.: 1.000   3rd Qu.:17.000  
#Max.   :2010-11-26 22:02:00   Max.   :11.122      Max.   :88.000   Max.   :80.000   Max.   :31.000  
#Year         Quarter         Month             Week         Weekdays              Day             Hour     
#Min.   :2006   Min.   :1.00   Min.   : 1.000   Min.   : 1.00   Length:2049280     Min.   : 1.00   Min.   : 0.0  
#1st Qu.:2007   1st Qu.:1.00   1st Qu.: 3.000   1st Qu.:13.00   Class :character   1st Qu.: 8.00   1st Qu.: 5.0  
#Median :2008   Median :2.00   Median : 6.000   Median :26.00   Mode  :character   Median :16.00   Median :12.0  
#Mean   :2008   Mean   :2.49   Mean   : 6.455   Mean   :26.29                      Mean   :15.71   Mean   :11.5  
#3rd Qu.:2009   3rd Qu.:3.00   3rd Qu.: 9.000   3rd Qu.:39.00                      3rd Qu.:23.00   3rd Qu.:18.0  
#Max.   :2010   Max.   :4.00   Max.   :12.000   Max.   :53.00                      Max.   :31.00   Max.   :23.0  
#Minute    
#Min.   : 0.0  
#1st Qu.:15.0  
#Median :30.0  
#Mean   :29.5  
#3rd Qu.:45.0  
#Max.   :59.0   

## initial exploration 

#sd(final$Sub_metering_1)
##NA
#sd(final$Sub_metering_2)
##NA
#sd(final$Sub_metering_3)
##NA
#mode(final$Sub_metering_1)
##0
#sum(final$Sub_metering_1)
##0
#sum(final$Sub_metering_2)
##0
#sum(final$Sub_metering_3)
##0
## Subset the second week of 2008 - All Observations 
houseweek <- filter(final, Year == 2008 & Week == 2)
## Plot subset houseWeek 
plot(houseweek$`Kitchen(Wh)`)

## Subset the 9th day of January 2008 - All observations
houseday <- filter(final, Year == 2008 & Month == 1 & Day == 9)
## Plot sub-meter 1
plot_ly(houseday, x = ~houseday$DateTime, 
        y = ~houseday$`Kitchen(Wh)`, type = 'scatter', mode = 'lines')


## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
plot_ly(houseday, x = ~houseday$DateTime, y = ~houseday$`Kitchen(Wh)`, 
        name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseday$`Laundry.Room(Wh)`, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseday$`Heater.&.A/C(Wh)`, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


## Subset the 9th day of January 2008 - 10 Minute frequency
houseDay10 <- filter(final, Year == 2008 & Month == 1 & Day == 9 
                     & (Minute == 0 | Minute == 10 | Minute == 20 | 
                          Minute == 30 | Minute == 40 | Minute == 50))
## Plot sub-meter 1, 2 and 3 with title, legend and labels - 10 Minute frequency
plot_ly(houseDay10, x = ~houseDay10$DateTime, y = ~houseDay10$`Kitchen(Wh)`, 
        name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay10$`Laundry.Room(Wh)`, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay10$`Heater.&.A/C(Wh)`, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


plot_ly(houseweek, x = ~houseweek$DateTime, y = ~houseweek$`Kitchen(Wh)`, 
        name = 'Kitchen', type = 'scatter', mode = 'lines') %>% 
  add_trace(y = ~houseweek$`Laundry.Room(Wh)`, name = 'Laundry Room', mode = 'lines')%>% 
  add_trace(y = ~houseweek$`Heater.&.A/C(Wh)`, name = "Water Heater & AC", mode = 'lines')


#Adjust granularity
houseweek4 <- filter(final, Year == 2008 & Week == 2
                     & (Minute == 0 | Minute == 15 | 
                          Minute == 30 | Minute == 45)) 

plot_ly(houseweek4, x = ~houseweek4$Weekdays, y = ~houseweek4$`Kitchen(Wh)`,
        name = "Kitchen", type = "scatter", mode = "lines")%>%
  add_trace(y = ~houseweek4$`Laundry.Room(Wh)`, name = "Laundry Room", mode = "lines")%>%
  add_trace(y = ~houseweek4$`Heater.&.A/C(Wh)`, name = "Water Heater & AC", mode = "lines")%>%
  layout(title = "2nd Week of Jan 2008",
         xaxis = list(title = "Weekdays"),
         yaxis = list (title = "Power (watt-hours)")) 


## Subset to one observation per week for 2007, 2008 and 2009
house070809weekly <- filter(final, (Year == 2007 | Year == 2008 | Year == 2009) &
                              Weekdays == "Tuesday" & Hour == 20 & Minute == 1)
#Time series for SubMeter 3
library(ggplot2)
library(ggfortify)
tsSM3_070809weekly3 <- ts(house070809weekly$`Heater.&.A/C(Wh)`, frequency = 52, start = c(2007,1))
autoplot(tsSM3_070809weekly3, ts.colour = 'red', xlab = "Time", ylab = "Watt Hours", 
         main = "Heater & AC")
plot.ts(tsSM3_070809weekly3, ts.colour = 'red' , xlab = "Time (Years)", ylab = "Watt Hours", main = "Heater & AC")

#Time series for Meter 1
tsSM1_070809weekly1 <- ts(house070809weekly$`Kitchen(Wh)`, frequency = 52, start = c(2007,1))
autoplot(tsSM1_070809weekly1, ts.colour = 'red', xlab = "Time", ylab = "Watt Hours", 
         main = "Heater & AC")
plot.ts(tsSM1_070809weekly1, xlab = "Time (Years)", ylab = "Watt Hours", main = "Kitchen")

#Time series for Meter 2
tsSM2_070809weekly2 <- ts(house070809weekly$`Laundry.Room(Wh)`, frequency = 52, start = c(2007,1))
autoplot(tsSM2_070809weekly2, ts.colour = 'red', xlab = "Time", ylab = "Watt Hours", 
         main = "Heater & AC")
plot.ts(tsSM2_070809weekly2, xlab = "Time (Years)", ylab = "Watt Hours", main = "Laundry Room")

#Time series Household
ts070809weekly <- ts(house070809weekly$`Household.Power(kW)`, frequency = 52, start = c(2007,1))
plot.ts(ts070809weekly, xlab = "Time (Years)", ylab = "kW-hours", main = "Whole House")


#Linear Regression
fitSM3 <- tslm(tsSM3_070809weekly3 ~ trend + season)
fitSM2 <- tslm(tsSM2_070809weekly2 ~ trend + season)
fitSM1 <- tslm(tsSM1_070809weekly1 ~ trend + season)

summary(fitSM3)
#Residual standard error: 7.863 on 104 degrees of freedom
#Multiple R-squared:  0.2639,	Adjusted R-squared:  -0.1042 
#F-statistic: 0.7169 on 52 and 104 DF,  p-value: 0.9077

## Create the forecast for sub-meter 3. Forecast ahead 20 time periods 
forecastfitSM3 <- forecast(fitSM3, h=20)
###gray areas in plot:The term regression artifacts refers to pseudoeffects from a regression type of analysis.
##These incorrect causal estimates are due to biases from causes other than the cause of interest. Note that 
##such artifacts are problems only when making causal inferences, not when merely predicting some future outcome.

## Plot the forecast for sub-meter 3. 
plot(forecastfitSM3)
## Create sub-meter 3 forecast with confidence levels 80 and 90
forecastfitSM3c <- forecast(fitSM3, h=20, level=c(80,90))
## Plot sub-meter 3 forecast, limit y and add labels
plot(forecastfitSM3c, ylim = c(0, 40), ylab= "Watt-Hours", xlab="Time")

## Create sub-meter 2 forecast with confidence levels 80 and 90
forecastfitSM2 <- forecast(fitSM2, h=20, level=c(80,90))
## Plot sub-meter 3 forecast, limit y and add labels
plot(forecastfitSM2, ylim = c(0, 40), ylab= "Watt-Hours", xlab="Time")

## Create sub-meter 1 forecast with confidence levels 80 and 90
forecastfitSM1 <- forecast(fitSM1, h=20, level=c(80,90))
## Plot sub-meter 3 forecast, limit y and add labels
plot(forecastfitSM1, ylim = c(0, 40), ylab= "Watt-Hours", xlab="Time")

summary(forecastfitSM1)
summary(forecastfitSM2)
summary(forecastfitSM3)

#Decompose
## Decompose Sub-meter 3 into trend, seasonal and remainder
components070809SM3weekly <- decompose(tsSM3_070809weekly3)
## Plot decomposed sub-meter 3
plot(components070809SM3weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM3weekly)

## Decompose Sub-meter 2 into trend, seasonal and remainder
components070809SM2weekly <- decompose(tsSM2_070809weekly2)
## Plot decomposed sub-meter 2
plot(components070809SM2weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM2weekly)

## Decompose Sub-meter 1 into trend, seasonal and remainder
components070809SM1weekly <- decompose(tsSM1_070809weekly1)
## Plot decomposed sub-meter 2
plot(components070809SM1weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM1weekly)

#Holt-Winters Forecasting
## Seasonal adjusting sub-meter 3 by subtracting the seasonal component & plot
tsSM3_070809Adjusted <- tsSM3_070809weekly3 - components070809SM3weekly$seasonal
autoplot(tsSM3_070809Adjusted)
## Test Seasonal Adjustment by running Decompose again. Note the very, very small scale for Seasonal
plot(decompose(tsSM3_070809Adjusted))
## Holt Winters Exponential Smoothing & Plot
tsSM3_HW070809 <- HoltWinters(tsSM3_070809Adjusted, beta=FALSE, gamma=FALSE)
plot(tsSM3_HW070809, ylim = c(0, 25))
## HoltWinters forecast & plot
tsSM3_HW070809for <- forecast(tsSM3_HW070809, h=25)
plot(tsSM3_HW070809for, ylim = c(0, 25), ylab= "Watt-Hours", xlab="Time - Sub-meter 3")
## Forecast HoltWinters with diminished confidence levels
tsSM3_HW070809forC <- forecast(tsSM3_HW070809, h=25, level=c(10,25))
## Plot only the forecasted area
plot(tsSM3_HW070809forC, ylim = c(0, 10), ylab= "Watt-Hours", xlab="Time - Sub-meter 3", start(2010))

## Seasonal adjusting sub-meter 2 by subtracting the seasonal component & plot
tsSM2_070809Adjusted <- tsSM2_070809weekly2 - components070809SM2weekly$seasonal
autoplot(tsSM2_070809Adjusted)
plot(decompose(tsSM2_070809Adjusted))
## Holt Winters Exponential Smoothing & Plot
tsSM2_HW070809 <- HoltWinters(tsSM2_070809Adjusted, beta=FALSE, gamma=FALSE)
plot(tsSM2_HW070809, ylim = c(0, 25)) 
## HoltWinters forecast & plot
tsSM2_HW070809for <- forecast(tsSM2_HW070809, h=25)
plot(tsSM2_HW070809for, ylim = c(0, 25), ylab= "Watt-Hours", xlab="Time - Sub-meter 2")
## Forecast HoltWinters with diminished confidence levels
tsSM2_HW070809forC <- forecast(tsSM2_HW070809, h=25, level=c(10,25))
## Plot only the forecasted area
plot(tsSM2_HW070809forC, ylim = c(0, 5), ylab= "Watt-Hours", xlab="Time - Sub-meter 2", start(2010))

## Seasonal adjusting sub-meter 1 by subtracting the seasonal component & plot
tsSM1_070809Adjusted <- tsSM1_070809weekly1 - components070809SM1weekly$seasonal
autoplot(tsSM1_070809Adjusted)
plot(decompose(tsSM1_070809Adjusted))
## Holt Winters Exponential Smoothing & Plot
tsSM1_HW070809 <- HoltWinters(tsSM1_070809Adjusted, beta=FALSE, gamma=FALSE)
plot(tsSM1_HW070809, ylim = c(0, 25)) 
## HoltWinters forecast & plot
tsSM1_HW070809for <- forecast(tsSM1_HW070809, h=25)
plot(tsSM2_HW070809for, ylim = c(0, 25), ylab= "Watt-Hours", xlab="Time - Sub-meter 1")
## Forecast HoltWinters with diminished confidence levels
tsSM1_HW070809forC <- forecast(tsSM1_HW070809, h=25, level=c(10,25))
## Plot only the forecasted area
plot(tsSM1_HW070809forC, ylim = c(0, 5), ylab= "Watt-Hours", xlab="Time - Sub-meter 1", start(2010))












