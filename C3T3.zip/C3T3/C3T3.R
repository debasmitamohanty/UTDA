###############
# Housekeeping
###############

# Clear objects if necessary
rm(list = ls())

# Clear console: CTRL + L

set.seed(123)

?getwd()

# get working directory
getwd()
# set working directory
setwd("/Users/debasmitamohanty/UT-R-Projects/C3T3")
dir()


################
# Load Packages 
################
install.packages("ggplot")
install.packages("caret", dependencies = c("Depends", "Suggests"))
install.packages("xgboost") 
install.packages("tidyverse")
install.packages("readxl")
install.packages("xlsx")
install.packages("dummies")
install.packages("lattice")
install.packages("purr")
install.packages("foreach")
install.packages("iterators")
install.packages("parallel")
install.packages("dplyr")
install.packages("reshape2")
install.packages("BBmisc")
install.packages("corrplot")
install.packages("survival")
install.packages("splines")
install.packages("plyr")
install.packages("plotly")
install.packages("usethis")
install.packages("magrittr")
install.packages("gbm")
install.packages ("rlang") 
library(caret)
library(corrplot)
library(readr)
library(mlbench)
library(plyr)
library(ggplot2)
library(labeling)
library(devtools)
library(C50)
library(gbm)
library(xgboost)
library(dplyr)
library(magrittr)



##############
# Import data
##############

##--- Load raw datasets ---##

# Load Train/Existing data (Dataset 1)
existing_products <- read.csv("existingproductattributes2017.csv", stringsAsFactors = FALSE, header=T)
str(existing_products)

View(existing_products)

##--- Load Predict/New data (Dataset 2) ---##

new_products <- read.csv("newproductattributes2017.csv", stringsAsFactors = FALSE, header=T)
str(new_products)

View(new_products)


################
# Evaluate data
################

##--- Dataset 1 ---##

str(existing_products) # 80 obs. of  18 variables:

#data.frame':	80 obs. of  18 variables:
# ProductType          : chr  "PC" "PC" "PC" "Laptop" ...
# ProductNum           : int  101 102 103 104 105 106 107 108 109 110 ...
# Price                : num  949 2250 399 410 1080 ...
# x5StarReviews        : int  3 2 3 49 58 83 11 33 16 10 ...
# x4StarReviews        : int  3 1 0 19 31 30 3 19 9 1 ...
# x3StarReviews        : int  2 0 0 8 11 10 0 12 2 1 ...
# x2StarReviews        : int  0 0 0 3 7 9 0 5 0 0 ...
# x1StarReviews        : int  0 0 0 9 36 40 1 9 2 0 ...
# PositiveServiceReview: int  2 1 1 7 7 12 3 5 2 2 ...
# NegativeServiceReview: int  0 0 0 8 20 5 0 3 1 0 ...
# Recommendproduct     : num  0.9 0.9 0.9 0.8 0.7 0.3 0.9 0.7 0.8 0.9 ...
# BestSellersRank      : int  1967 4806 12076 109 268 64 NA 2 NA 18 ...
# ShippingWeight       : num  25.8 50 17.4 5.7 7 1.6 7.3 12 1.8 0.75 ...
# ProductDepth         : num  23.9 35 10.5 15 12.9 ...
# ProductWidth         : num  6.62 31.75 8.3 9.9 0.3 ...
# ProductHeight        : num  16.9 19 10.2 1.3 8.9 ...
# ProfitMargin         : num  0.15 0.25 0.08 0.08 0.09 0.05 0.05 0.05 0.05 0.05 ...
# Volume               : int  12 8 12 196 232 332 44 132 64 40 ...


names(existing_products)

# "ProductType"           "ProductNum"            "Price"                
# "x5StarReviews"         "x4StarReviews"         "x3StarReviews"        
# "x2StarReviews"         "x1StarReviews"         "PositiveServiceReview"
# "NegativeServiceReview" "Recommendproduct"      "BestSellersRank"      
# "ShippingWeight"        "ProductDepth"          "ProductWidth"         
# "ProductHeight"         "ProfitMargin"          "Volume"     

head(existing_products)

tail(existing_products)

# check for missing values 
anyNA(existing_products) # This data set indicates "True" - There are NAs



##--- Dataset 2 ---##

str(new_products)  # 24 obs. of  18 variables: 

# data.frame':	24 obs. of  18 variables:
# ProductType          : chr  "PC" "PC" "Laptop" "Laptop" ...
# ProductNum           : int  171 172 173 175 176 178 180 181 183 186 ...
# Price                : num  699 860 1199 1199 1999 ...
# x5StarReviews        : int  96 51 74 7 1 19 312 23 3 296 ...
# x4StarReviews        : int  26 11 10 2 1 8 112 18 4 66 ...
# x3StarReviews        : int  14 10 3 1 1 4 28 7 0 30 ...
# x2StarReviews        : int  14 10 3 1 3 1 31 22 1 21 ...
# x1StarReviews        : int  25 21 11 1 0 10 47 18 0 36 ...
# PositiveServiceReview: int  12 7 11 2 0 2 28 5 1 28 ...
# NegativeServiceReview: int  3 5 5 1 1 4 16 16 0 9 ...
# Recommendproduct     : num  0.7 0.6 0.8 0.6 0.3 0.6 0.7 0.4 0.7 0.8 ...
# BestSellersRank      : int  2498 490 111 4446 2820 4140 2699 1704 5128 34 ...
# ShippingWeight       : num  19.9 27 6.6 13 11.6 5.8 4.6 4.8 4.3 3 ...
# ProductDepth         : num  20.63 21.89 8.94 16.3 16.81 ...
# ProductWidth         : num  19.2 27 12.8 10.8 10.9 ...
# ProductHeight        : num  8.39 9.13 0.68 1.4 0.88 1.2 0.95 1.5 0.97 0.37 ...
# ProfitMargin         : num  0.25 0.2 0.1 0.15 0.23 0.08 0.09 0.11 0.09 0.1 ...
# Volume               : int  0 0 0 0 0 0 0 0 0 0 ...

names(new_products)

#Names of New Products
# "ProductType"           "ProductNum"            "Price"                
# "x5StarReviews"         "x4StarReviews"         "x3StarReviews"        
# "x2StarReviews"         "x1StarReviews"         "PositiveServiceReview"
# "NegativeServiceReview" "Recommendproduct"      "BestSellersRank"      
# "ShippingWeight"        "ProductDepth"          "ProductWidth"         
# "ProductHeight"         "ProfitMargin"          "Volume"    

head(new_products)

tail(new_products)

anyNA(new_products)



#############
# Preprocess
#############

## Checking for Duplicates

sum(duplicated(new_products[,c(1,4:18)]))

## [1] 0
#Existing_Products <- Existing_Products[-c(35:41),]
Duplicates <- existing_products[c(32:41),]
Duplicates[3,3] <- sum(Duplicates[3:10,3])/8
Duplicates <- Duplicates[1:3,]
existing_products<- existing_products[-c(32:41),]
existing_products  <- rbind(existing_products, Duplicates)


#########################
#Remove Unwanted Columns
#########################

#We checked in the previous project that some columns were not useful and just added noise to our prediction model. The columns are:
#1. Product dimensions (width, Depth and Height)
#2. Best Sellers Rank
#3. Shipping Weight
#4. Product Num (we don't want the id to add 'noise')

#We proceed to get rid of the aforementioned columns in both df (they don't need to be the same for prediction, but it's good practice)

existing_products<- dplyr::select(existing_products,-c(ProductNum,BestSellersRank,ShippingWeight,ProductDepth, ProductWidth, ProductHeight))

new_products  <- dplyr::select(new_products,-c(ProductNum,BestSellersRank,ShippingWeight,ProductDepth, ProductWidth, ProductHeight))



## Checking For Outliers

p <- ggplot(existing_products) + 
  geom_point(aes(ProductType, Volume, size = Volume, colour = ProductType)) + theme(axis.text.x = element_text(angle = 45, hjust = 1))
p + 
  scale_size_binned()

p + 
  scale_y_binned()

ggplot(existing_products, aes(ProductType, Volume)) +
  geom_boxplot(aes(colour = ProductType, fill = after_scale(alpha(colour, 0.4)))) + theme(axis.text.x = element_text(angle = 45, hjust = 1))

#We have few outliers .
boxplot(existing_products$Volume, plot = FALSE)$out

## [1]  2052  2140 11204  1896  7036  1684
#But we only want to remove the two extreme outliers because our dataset is small
existing_products <- existing_products[-which(existing_products$Volume > 7000),]



##############
# Scale Data#We do the same in NewProd df
for (i in c(2:11)){new_products[,i] <- scale(new_products[,i])}

##############

# Scaling Data because different variables have different units, 
for (i in c(2:11)){existing_products[,i] <- scale(existing_products[,i])}



##############
# Correlation
##############


# The Correlation Matrix is only going to work with numeric values, so we create another df as to avoid messing with the current one, so that we can run a correlation matrix. 
# We do this before dummifying, because once we dummify we'll have lots of variables and the correlation matrix will be way harder to read.
existing_products_corr <- existing_products[,-c(1:2)]



CorrData2 <- cor(existing_products_corr)
corrplot(CorrData2, order="hclust", method = "color",
         tl.col = "black", tl.srt = 90 , tl.cex = 0.7, tl.pos = "t")



#In order to find out the relationship between the label and the Product Type (categorical), we are going to use the ANOVA test.
ANOVA <- aov(existing_products$Volume~ existing_products$ProductType)
summary(ANOVA)

###############################Df   Sum Sq Mean Sq F value Pr(>F)
#existing_products$ProductType 11  5075621  461420   1.473  0.166
#Residuals                     59 18487579  313349 



# dummify the data

newDataFrame <- dummyVars(" ~ .", data = existing_products)

readyData <- data.frame(predict(newDataFrame, newdata = existing_products))

#cross-check to ensure there are no nominal variables-check the structure

str(readyData)

#Check for missing data - all the columns/sections with NA's

summary(readyData)

#delete all columns with missing data

readyData$ProductHeight <- NULL
readyData$BestSellersRank <- NULL


###############
# Collinearity
###############

#We now look for collinearity in the newly dummified df
CorrData <- cor(readyData)
CorNames <- findCorrelation(CorrData, cutoff = 0.9, verbose = TRUE, names = TRUE)

#The above function recommends what columns we should erase based on collinearity. So we proceed to do that:
existing_products <- existing_products[, - which(names(existing_products) %in% CorNames)]

###########
# Modeling
###########

set.seed(123)
#assign names and calculate the training size and test size

trainSize <- round(nrow(readyData)*0.7)
testSize <- round(nrow(readyData)- trainSize)
#check training and test size

trainSize
## [1] 50
testSize
## [1] 21

#train the dataset

training_indices<-sample(seq_len(nrow(readyData)),size =trainSize)

#Assign the training and test data into the names trainset and testsize

trainSet<-readyData[training_indices,]
testSet<-readyData[-training_indices,]

#run linear regression model

readydata_LM<-lm(Volume ~ ., trainSet)

#check the outcome of the linear regression model

readydata_LM

# plot the results
plot(readydata_LM) 


#get a summary of the content of the finding
summary(readydata_LM)

## Warning in summary.lm(readydata_LM): essentially perfect fit: summary may
## be unreliable

#non-parametric machine learning models - support vector machine, random forest and Gradient Boost. 


######################
# Random Forest - RF
######################

#randomize the dataset

set.seed(123)
#assign names and calculate the training size and test size

trainSize <- round(nrow(readyData)*0.7)
testSize <- round(nrow(readyData)- trainSize)

#check training and test size

trainSize
## [1] 50
testSize
## [1] 21

#train the dataset

training_indices<-sample(seq_len(nrow(readyData)),size =trainSize)
#Assign the training and test data into the names trainset and testsize

trainSet<-readyData[training_indices,]
testSet<-readyData[-training_indices,]

#10 fold cross validation

fit_Control <- trainControl(method = "repeatedcv", number = 10, repeats = 1)

#train Random Forest Regression model with a tuneLenght = 1 (trains with 1 mtry value for RandomForest)

readydata_rf <- train(Volume ~ ., data = trainSet, method = "rf", trControl=fit_Control, tuneLength = 1, importance = T)

#training results
readydata_rf
#Random Forest 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Cross-Validated (10 fold, repeated 1 times) 
#Summary of sample sizes: 46, 46, 44, 45, 46, 46, ... 
#Resampling results:
  
 # RMSE      Rsquared   MAE     
#200.2495  0.9539168  131.9296

#see a summary of the model created
summary(readydata_rf)


#predict the findings
readydata_rf_predict<-predict(object = readydata_rf, newdata=testSet, na.action = na.pass)


#to see all the predictions
readydata_rf_predict
# readydata_rf_predict
#1          3          4         11         13         16         18         20         22         24         30 
#42.68935   26.60102  224.46590  197.89174   63.83653   69.91446 1014.00655  104.01967 1384.67991  134.71153   36.95403 
#44         48         52         55         56         58         60         67         75         77 
#403.51530 1469.49754  346.04480  608.84051  359.68693  201.11958  303.90000 1009.07832   36.49875  149.89196 


#this tells the most important independent variables
varImp(readydata_rf)

#rf variable importance

#only 20 most important variables shown (out of 61)

#Overall
#PositiveServiceReview        100.00
#x5StarReviews                 98.50
#x4StarReviews                 69.38
#x3StarReviews                 58.64
#x2StarReviews                 57.25
#NegativeServiceReview         52.26
#x1StarReviews                 50.88
#ShippingWeight                44.47
#BestSellersRank7              35.91
#ProductTypeExtend

#Error check 1 - test of testSet result
postResample(testSet$Volume, readydata_rf_predict)
#RMSE    Rsquared         MAE 
#192.0748554   0.9023448 112.6873609 

#Error check 2 - test of trainSet result
readydata_rf_predict2 <- predict(object = readydata_rf, 
                                 newdata = trainSet)


postResample(testSet$Volume, readydata_rf_predict2)
#RMSE Rsquared      MAE 
#737.4774       NA 512.3178 

#Error check 3 - confusion matrix - not working 
confusionMatrix(table(testSet$Volume, readydata_rf_predict))

#because the confusion matrix directly is giving an error, then use the union function to unify it

U <- union(readydata_rf_predict, testSet$Volume)
#create a model that incorporates the both items as factor and adds the unifying model done earlier 
readydata_conf_matrix <- table(factor(readydata_rf_predict, U), factor(testSet$Volume, U))

#run the confusion matrix 
confusionMatrix(readydata_conf_matrix)

##############################
#Support Vector Machine (SVM)
##############################

#this helps to randomize the dataset

set.seed(123)

#assign names and calculate the taining size and test size
trainSize <- round(nrow(readyData)*0.7)
testSize <- round(nrow(readyData)- trainSize)

#check training and test size
trainSize
## [1] 50
testSize
## [1] 21


#train the dataset
training_indices<-sample(seq_len(nrow(readyData)),size =trainSize)

#Assign the training and test data into the names trainset and testsize
trainSet<-readyData[training_indices,]
testSet<-readyData[-training_indices,]

#10 fold cross validation
fit_Control <- trainControl(method = "repeatedcv", number = 10, repeats = 1)

#train Support Vector Machine model with a tuneLenght = 1 (trains with 1 mtry value for SVM)
readydata_svm <- caret::train(Volume ~ ., 
                              data = trainSet, 
                              method = 'svmLinear', 
                              trControl=fit_Control)

## Warning message:
 # In .local(x, ...) : Variable(s) `' constant. Cannot scale data.

#training results - run the findings
readydata_svm

## Support Vector Machines with Linear Kernel 
## 
## 50 samples
## 22 predictors
## 
## No pre-processing
## Resampling: Cross-Validated (10 fold, repeated 1 times) 
## Summary of sample sizes: 51, 50, 50, 50, 52, 49, ... 
## Resampling results:
## 
##   RMSE     Rsquared   MAE     
##   297.188  0.9449585  203.8192
## 
## Tuning parameter 'C' was held constant at a value of 1

summary(readydata_svm)
## Length  Class   Mode 
##      1   ksvm     S4

#predict the findings
readydata_svm_predict<-predict(object = readydata_svm, newdata=testSet, na.action = na.pass)

#to see all the predictions
readydata_svm_predict

#1          3          4         11         13         16         18         20         22         24         30 
#56.61753   55.26492  232.12108  129.02024   98.24024   87.89758 1011.46764   94.37711 1595.26840  130.52135   37.07303 
#44         48         52         55         56         58         60         67         75         77 
#414.57177 2292.88194  271.79359  903.44495  376.19728  139.25874  326.58227  832.84749   43.60819  131.46293 



#######################
## Variable Importance
#######################

#this tells the most important independent variables
varImp(readydata_svm)
#loess r-squared variable importance

#only 20 most important variables shown (out of 22)

#Overall
#x5StarReviews              100.0000
#PositiveServiceReview       96.0850
#x4StarReviews               67.6628
#x3StarReviews               57.2721
#x2StarReviews               55.6660
#x1StarReviews               53.3306
#NegativeServiceReview       35.6284
#Recommendproduct            19.2414

#Error check 1 - test of testSet result
postResample(testSet$Volume, readydata_svm_predict)

#RMSE   Rsquared        MAE 
#87.7586627  0.9864785 53.6013520 

readydata_svm_predict2 <- predict(object = readydata_svm, 
                                  newdata = trainSet)

postResample(testSet$Volume, readydata_svm_predict2)

## Warning in pred - obs: longer object length is not a multiple of shorter
## object length

## Warning in pred - obs: longer object length is not a multiple of shorter
## object length


#Error check 3 - confusion matrix - not yet working round(prop.table(confusionMatrix(testSetVolume,readydatasvmpredict)table))
confusionMatrix(table(testSet$Volume, readydata_svm_predict))

##Error Message: Error in !all.equal(nrow(data), ncol(data)) : invalid argument type

#because the confusion matrix directly is giving an error, then use the union function to unify it
U <- union(readydata_svm_predict, testSet$Volume)

#create a model that incorporates the both items as factor and adds the unifying model done earlier
readydata_conf_matrix <- table(factor(readydata_svm_predict, U), factor(testSet$Volume, U))

#run the confusion matrix
confusionMatrix(readydata_conf_matrix) 


####################################
## Gradient Boosting Machine (GBM)
####################################

set.seed(123)

#assign names and calculate the training size and test size
trainSize <- round(nrow(readyData)*0.7)
testSize <- round(nrow(readyData)- trainSize)

#check training and test size
trainSize
## [1] 50
testSize
## [1] 21


#train the dataset
training_indices<-sample(seq_len(nrow(readyData)),size =trainSize)

#Assign the training and test data into the names trainset and testsize
trainSet<-readyData[training_indices,]
testSet<-readyData[-training_indices,]

#Tuning Parameters
fit_Control <- trainControl(method = "cv", number = 10)


readydata_gbm = train(Volume ~., data = trainSet, method="gbm", trControl=fit_Control)

readydata_gbm
#Stochastic Gradient Boosting 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Cross-Validated (10 fold) 
#Summary of sample sizes: 45, 44, 44, 45, 44, 45, ... 
#Resampling results across tuning parameters:
  
#  interaction.depth  n.trees  RMSE      Rsquared   MAE     
#1                   50      369.3257  0.7055839  273.6990
#1                  100      369.6166  0.7264513  279.8946
#1                  150      355.6573  0.7419888  269.5858

#see a summary of the model created

summary(readydata_gbm)


########################
#Tuning GBM Parameters
########################

myGrid <- expand.grid(n.trees = c(50),
                      interaction.depth = c(3),
                      shrinkage = c(0.1),
                      n.minobsinnode = c(10))

set.seed(123)

readydata_gbm_tune <- train(Volume ~ ., data = trainSet, method = "gbm", distribution = "gaussian",
                      trControl = fit_Control, verbose = FALSE, tuneGrid = myGrid)

#Warning message:
#In (function (x, y, offset = NULL, misc = NULL, distribution = "bernoulli",  :
#                variable 4: ProductTypeGameConsole has no variation.

readydata_gbm_tune
# readydata_gbm_tune
#Stochastic Gradient Boosting 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Cross-Validated (10 fold) 
#Summary of sample sizes: 44, 46, 45, 45, 44, 46, ... 
#Resampling results:
  
#  RMSE      Rsquared   MAE     
#335.2659  0.7614248  248.6427

#Tuning parameter 'n.trees' was held constant at a value of 50
#Tuning parameter 'interaction.depth' was held constant at a value

summary(readydata_gbm_tune)

##################
# Best Tune
##################

set.seed(123)

myGrid <- readydata_gbm_tune$bestTune

readydata_gbm_tune <- train(Volume ~ ., data = trainSet, method = "gbm",
                            trControl = fit_Control, verbose = FALSE, tuneGrid = myGrid)

# Warning message:
# In (function (x, y, offset = NULL, misc = NULL, distribution = "bernoulli",  :
#                 variable 4: ProductTypeGameConsole has no variation.

readydata_gbm_tune



#predict the findings
readydata_gbm_tune_predict<-predict(object = readydata_gbm_tune, newdata=testSet, na.action = na.pass)


#to see all the predictions
readydata_gbm_tune_predict
#readydata_gbm_tune_predict
#[1]  -34.78656   28.02478  421.50929  192.54921   98.74494  113.15700 1036.05650  -84.45879  996.70891  174.50900   82.24226
#[12] 1112.32681 1071.58440  544.95791  951.81147  726.80812  231.81958  578.29875  928.00795  -34.78656  196.31081


#this tells the most important independent variables
varImp(readydata_gbm_tune)
#gbm variable importance

#only 20 most important variables shown (out of 22)

#Overall
#x5StarReviews               100.000
#x4StarReviews                21.081
#x1StarReviews                10.965
#PositiveServiceReview         9.280
#NegativeServiceReview         8.157
#ProfitMargin                  7.554
#Price                         7.518
#Recommendproduct              6.415
#x3StarReviews                 3.703
#x2StarReviews                 2.484

#Error check 1 - test of testSet result
postResample(testSet$Volume, readydata_gbm_tune_predict)

# postResample(testSet$Volume, readydata_gbm_tune_predict)
#RMSE    Rsquared         MAE 
#354.8606773   0.5944966 238.4225241 

#Error check 2 - test of trainSet result
readydata_gbm_tune_predict2 <- predict(object = readydata_gbm_tune, 
                                 newdata = trainSet)


postResample(testSet$Volume, readydata_gbm_tune_predict2)

# Warning messages:
#1: In pred - obs :
#  longer object length is not a multiple of shorter object length
#2: In pred - obs :
#  longer object length is not a multiple of shorter object length



#Error check 3 - confusion matrix - not working confusionMatrix(table(testSet$Volume, readydata_gbm_tune_predict2))
#because the confusion matrix directly is giving an error, then use the union function to unify it
confusionMatrix(table(testSet$Volume, readydata_gbm_tune_predict))

#because the confusion matrix directly is giving an error, then use the union function to unify it
U <- union(readydata_gbm_tune_predict, testSet$Volume)

#create a model that incorporates the both items as factor and adds the unifying model done earlier
readydata_gbm_tune_conf_matrix <- table(factor(readydata_gbm_tune_predict, U), factor(testSet$Volume, U))

#run the confusion matrix
confusionMatrix(readydata_gbm_tune_conf_matrix) 


######################################################################################

######################################################################################

#The chosen models are looped below
Four_Models   <- c("lm", "rf", "svmLinear", "gbm")

#We create an empty variable so we can later assign all results to it
compare.model <- c()


for (i in Four_Models){
  model         <- caret::train(Volume ~., data = trainSet, method = i, )
  pred          <- predict(model, newdata = testSet)
  pred.metric   <- postResample(testSet$Volume, obs = pred)
  compare.model <- cbind(pred.metric, compare.model)
}


#That's why we create a list with all models so that we can later choose the model
methods <- list()

#We will save them in the variable previously created
for (i in Four_Models) {
  methods[[i]] <- caret::train(Volume ~., data = trainSet, method = i )
}

## Call Function
methods

#Call Function
#> methods
#$lm
#Linear Regression 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Bootstrapped (25 reps) 
#Summary of sample sizes: 50, 50, 50, 50, 50, 50, ... 
#Resampling results:
  
 # RMSE          Rsquared  MAE         
#3.589199e-12  1         1.432178e-12

#Tuning parameter 'intercept' was held constant at a value of TRUE

#$rf
#Random Forest 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Bootstrapped (25 reps) 
#Summary of sample sizes: 50, 50, 50, 50, 50, 50, ... 
#Resampling results across tuning parameters:
  
 # mtry  RMSE      Rsquared   MAE      
#2    301.9463  0.8523119  198.16604
#12    175.5788  0.9396720   95.63931
#22    156.5205  0.9464350   83.36618

#RMSE was used to select the optimal model using the smallest value.
#The final value used for the model was mtry = 22.

#$svmLinear
#Support Vector Machines with Linear Kernel 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Bootstrapped (25 reps) 
#Summary of sample sizes: 50, 50, 50, 50, 50, 50, ... 
#Resampling results:
  
 # RMSE     Rsquared   MAE     
#652.131  0.8400516  327.6774

#Tuning parameter 'C' was held constant at a value of 1

#$gbm
#Stochastic Gradient Boosting 

#50 samples
#22 predictors

#No pre-processing
#Resampling: Bootstrapped (25 reps) 
#Summary of sample sizes: 50, 50, 50, 50, 50, 50, ... 
#Resampling results across tuning parameters:
  
#  interaction.depth  n.trees  RMSE      Rsquared   MAE     
#1                   50      341.1608  0.7216648  233.5769
#1                  100      337.8842  0.7143271  238.8228
#1                  150      341.4402  0.7081015  243.1466
#2                   50      337.1107  0.7239112  235.8981
#2                  100      334.9406  0.7199331  238.2879
#2                  150      336.9436  0.7143111  242.5010
#3                   50      346.1011  0.7108879  241.1803
#3                  100      340.5626  0.7131234  240.5511
#3                  150      345.1850  0.7027714  245.8457

#Tuning parameter 'shrinkage' was held constant at a value of 0.1
#Tuning parameter 'n.minobsinnode' was held constant at a value
#of 10
#RMSE was used to select the optimal model using the smallest value.
#The final values used for the model were n.trees = 100, interactio

## Compare Models
colnames(compare.model) <- Four_Models
compare.model

#             lm         rf       svmLinear          gbm
#RMSE     331.2745515 87.7586627 139.2018759 4.640847e-13
#Rsquared   0.6533391  0.9864785   0.9419804 1.000000e+00
#MAE      248.2452827 53.6013520  71.8244762 3.852157e-13


################################
# Analyzing and plotting errors
################################

compare.model.melt <- melt(compare.model, varnames = c("metric", "model"))
compare.model.melt <- as.data.frame(compare.model.melt)
compare.model.melt

#All models offer quite different results, which indicates the predictions will have high variance between models.  
#Based on errors, the SVM stands out in MAE (smaller error than others). RMSE is pretty similar in all.
#As for the RSquared, RF performes better than SVM here, but SVM comes in second, so we choose this model.
for(i in c("RMSE","Rsquared","MAE")) {
  metric <-  compare.model.melt %>%  filter(metric == i)
  gg <- ggplot(metric, aes(model,value))
  print(gg + geom_bar(stat = "identity") + ggtitle(i))
}
#########################################################################################
##########################################
# Testing the models on the other data set
##########################################

##--- Dataset 2 ---##

new_products <- read.csv("newproductattributes2017.csv", stringsAsFactors = FALSE, header=T)
str(new_products)
#'data.frame':	24 obs. of  18 variables:
#  $ ProductType          : chr  "PC" "PC" "Laptop" "Laptop" ...
#$ ProductNum           : int  171 172 173 175 176 178 180 181 183 186 ...
#$ Price                : num  699 860 1199 1199 1999 ...
#$ x5StarReviews        : int  96 51 74 7 1 19 312 23 3 296 ...
#$ x4StarReviews        : int  26 11 10 2 1 8 112 18 4 66 ...
#$ x3StarReviews        : int  14 10 3 1 1 4 28 7 0 30 ...
#$ x2StarReviews        : int  14 10 3 1 3 1 31 22 1 21 ...
#$ x1StarReviews        : int  25 21 11 1 0 10 47 18 0 36 ...
#$ PositiveServiceReview: int  12 7 11 2 0 2 28 5 1 28 ...
#$ NegativeServiceReview: int  3 5 5 1 1 4 16 16 0 9 ...
#$ Recommendproduct     : num  0.7 0.6 0.8 0.6 0.3 0.6 0.7 0.4 0.7 0.8 ...
#$ BestSellersRank      : int  2498 490 111 4446 2820 4140 2699 1704 5128 34 ...
#$ ShippingWeight       : num  19.9 27 6.6 13 11.6 5.8 4.6 4.8 4.3 3 ...
#$ ProductDepth         : num  20.63 21.89 8.94 16.3 16.81 ...
#$ ProductWidth         : num  19.2 27 12.8 10.8 10.9 ...
#$ ProductHeight        : num  8.39 9.13 0.68 1.4 0.88 1.2 0.95 1.5 0.97 0.37 ...
#$ ProfitMargin         : num  0.25 0.2 0.1 0.15 0.23 0.08 0.09 0.11 0.09 0.1 ...
#$ Volume               : int  0 0 0 0 0 0 0 0 0 0 ...




names(new_products)

#Names of New Products
# "ProductType"           "ProductNum"            "Price"                
# "x5StarReviews"         "x4StarReviews"         "x3StarReviews"        
# "x2StarReviews"         "x1StarReviews"         "PositiveServiceReview"
# "NegativeServiceReview" "Recommendproduct"      "BestSellersRank"      
# "ShippingWeight"        "ProductDepth"          "ProductWidth"         
# "ProductHeight"         "ProfitMargin"          "Volume"    

head(new_products)

tail(new_products)

anyNA(new_products)


############################
# Preprocess Newprod data
############################


## Checking for Duplicates
#Because we have worked with these products before, and because the dataset is small, we can observe duplicates just by looking at the df itself. We find out all 'ExtendedWarranty' products share the same values in everything (including exact number of reviews of all types) except for a small different in price. In a business sense, We conclude this is because warranties are sold alongside different products, only the same type of warranty is included, but will vary in price proportionally to the price itself. We should treat them as the same products and remove all but one.

#Showing the 6 duplicates:
#IMPORTANT NOTE: It's good practice to remove the columns by name instead of by column number, so that if we do changes in dataset later, and we reload these commands, we won't mess up unwanted columns.

sum(duplicated(new_products[,c(1,4:18)]))

# [1] 0


#########################
#Remove Unwanted Columns
#########################

#We checked in the previous project that some columns were not useful and just added noise to our prediction model. The columns are:
#1. Product dimensions (width, Depth and Height)
#2. Best Sellers Rank
#3. Shipping Weight
#4. Product Num (we don't want the id to add 'noise')

#We proceed to get rid of the aforementioned columns in both df (they don't need to be the same for prediction, but it's good practice)



new_products  <- dplyr::select(new_products,-c(ProductNum,BestSellersRank,ShippingWeight,ProductDepth, ProductWidth, ProductHeight))



##############
# Scale Data
##############

# Scaling Data because different variables have different units, we are going to scale all numeric variables (except label):

#We do the same in NewProd df
for (i in c(2:11)){new_products[,i] <- scale(new_products[,i])}

# dummify the data

newDataFrame <- dummyVars(" ~ .", data = new_products)

readyDataNP <- data.frame(predict(newDataFrame, newdata = new_products))

#cross-check to ensure there are no nominal variables-check the structure

str(readyDataNP)

#Check for missing data - all the columns/sections with NA's

summary(readyDataNP)


###############
# Collinearity
###############

#We now look for collinearity in the newly dummified df
CorrData <- cor(readyDataNP)## warning standard deviation is 0
CorNames <- findCorrelation(CorrData, cutoff = 0.9, verbose = TRUE, names = TRUE)

#The above function recommends what columns we should erase based on collinearity. So we proceed to do that:
new_products <- new_products[, - which(names(new_products) %in% CorNames)]

#############################################
# Predict the Findings Using RF-Trained Model
#############################################

readyDataNP_rf_predict_newprod<-predict(object = readydata_rf, newdata=readyDataNP, na.action = na.pass)

## To see all the predictions
readyDataNP_rf_predict_newprod

#1          2          3          4          5          6          7          8          9         10         11 
#567.91821  170.15810  290.27892   59.33352   60.69918   69.41889  987.20626  194.83531   53.04030  968.39232 1507.08018 
#12         13         14         15         16         17         18         19         20         21         22 
#333.52476  791.33462   93.82626  281.96056 1142.37559   76.32688   92.08693   80.89886  118.36037  102.97148   71.23427 
#23         24 
#68.61899 1473.04665 

###############################################
# Predict the Findings Using SVM-Trained Model
##############################################

#predict the findings for the new product SVM - trained model name and the dataset is meant to be inside the bracket
readydataNP_svm_predict_newprod<-predict(object = readydata_svm, newdata=readyDataNP, na.action = na.pass)

#to see all the predictions
readydataNP_svm_predict_newprod
#1          2          3          4          5          6          7          8          9         10         11 
#320.06282  234.60528  285.13611  170.24663  156.83838  179.88366  686.66004  170.38823  163.18330  657.99181 1889.76518 
#12         13         14         15         16         17         18         19         20         21         22 
#334.71014  352.39221  244.19298  255.85114  910.65281  160.58763  215.24783  200.65945  184.61148  241.58226  150.28396 
#23         24 
#68.12803 2582.97586 


##############################################
# Predict the Findings Using GBM-Trained Model
##############################################

#predict the findings for the new product GBM - trained model name and the dataset is meant to be inside the bracket
readydataNP_gbm_tune_predict_newprod<-predict(object = readydata_gbm_tune, newdata=readyDataNP, na.action = na.pass)

#to see all the predictions
readydataNP_gbm_tune_predict_newprod

#1]  705.20335  324.66377  382.77770   98.59275   19.74343  139.75945 1036.05650  196.19102  164.05571 1020.82597 1075.70287
#[12]  767.87690  845.63596  284.32253  364.77014 1091.41686  268.28456  379.77488  244.85015  290.65828  340.72752  237.36982
#[23]  136.77226  992.34179

############################################
# New Products Plus Predictions_RF_File.csv
############################################


## Steps to add data/findings to the dataset. 
# How: new prod file is assigned into a new file named newprod_pluspredictions 

# First we add the data/findings to the RF predictions df
newprod_pluspredictionsrf <- readyDataNP

# Next, combine the final predictions from each of the RF models
newprod_pluspredictionsrf$pred <- predict(object = readydata_rf, newdata = readyDataNP)

# Finally, we add the predicted RF data to the predictions column in the newprod_plusprediction file
newprod_pluspredictionsrf$predictions <- readyDataNP_rf_predict_newprod

# Write the newly created df file.csv to your dedicated workspace
write.csv(newprod_pluspredictionsrf, file="newprod_pluspredictionsrf.csv", row.names = TRUE)



############################################
# New Products Plus Predictions_SVM_File.csv
############################################

## Steps to add data/findings to the dataset. 
# How: new prod file is assigned into a new file named newprod_pluspredictions 

# First we add the data/findings to the SVM predictions df
newprod_pluspredictionssvm <- readyDataNP

# Next, combine the final predictions from each of the SVM models
newprod_pluspredictionssvm$pred <- predict(object = readydata_svm, newdata = readyDataNP)

# Finally, we add the predicted SVM data to the predictions column in the newprod_plusprediction file
newprod_pluspredictionssvm$predictions <- readydataNP_svm_predict_newprod

# Write the newly created df file.csv to your dedicated workspace
write.csv(newprod_pluspredictionssvm, file="newprod_pluspredictionssvm.csv", row.names = TRUE)

############################################
# New Products Plus Predictions_GBM_File.csv
############################################

## Steps to add data/findings to the dataset. 
# How: new prod file is assigned into a new file named newprod_pluspredictions 

# First we add the data/findings to the GBM predictions df
newprod_pluspredictionsgbm <- readyDataNP

# Next, combine the final predictions from each of the GBM models
newprod_pluspredictionsgbm$pred <- predict(object = readydata_gbm_tune, newdata = readyDataNP)

# Finally, we add the predicted GBM data to the predictions column in the newprod_plusprediction file
newprod_pluspredictionsgbm$predictions <- readydataNP_gbm_tune_predict_newprod

# Write the newly created df file.csv to your dedicated workspace
write.csv(newprod_pluspredictionsgbm, file="newprod_pluspredictionsgbm.csv", row.names = TRUE)

###****Process Ends****