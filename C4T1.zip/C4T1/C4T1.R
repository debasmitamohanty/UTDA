
###############
# Housekeeping
###############

# get working directory
getwd()
#[1] "/Users/debasmitamohanty/UT-R-Projects/C4T1"
# set working directory
setwd("/Users/debasmitamohanty/UT-R-Projects/C4T1")
dir()


################
# Load packages
################
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("RMySQL")
install.packages("dplyr")
install.packages("dbConnect")
install.packages("lubridate")
install.packages("ggfortify")
install.packages("plotly")
install.packages("forecast")
install.packages("DBI")
library(dplyr)
library(RMySQL)
library(dbConnect)
library(lubridate)
library(ggplot2)
library(plotly)
library(ggfortify)
library(forecast)
library(tidyverse)


##############
# Import data
##############

##--- Load raw datasets ---##

# Load Train/Existing data (Dataset 1)

# Read a txt file
oob_hpc <- read.csv("household_power_consumption.txt", stringsAsFactors = FALSE, header=T)



## Create a database connection 
con = dbConnect(MySQL(), user='deepAnalytics', password='Sqltask1234!',
                dbname='dataanalytics2018', host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')


## List the tables contained in the database 
dbListTables(con)
##[1] "iris"    "yr_2006" "yr_2007" "yr_2008" "yr_2009" "yr_2010"

## Use asterisk to specify all attributes for download
irisALL <- dbGetQuery(con, "SELECT * FROM iris")
str(irisALL)

#Downloading all attributes for all years
yr_2006 <- dbGetQuery(con, "SELECT * FROM yr_2006")
yr_2007 <- dbGetQuery(con, "SELECT * FROM yr_2007") 
yr_2008 <- dbGetQuery(con, "SELECT * FROM yr_2008") 
yr_2009 <- dbGetQuery(con, "SELECT * FROM yr_2009") 
yr_2010 <- dbGetQuery(con, "SELECT * FROM yr_2010")
#Warning message:
 # In .local(conn, statement, ...) :
  #Unsigned INTEGER in col 0 imported as numeric

dbListFields(con,'yr_2006 ')
#dbListFields(con,'yr_2006 ')
#[1] "id"                    "Date"                  "Time"                  "Global_active_power"  
#[5] "Global_reactive_power" "Global_intensity"      "Voltage"               "Sub_metering_1"       
#[9] "Sub_metering_2"        "Sub_metering_3"  


attributes(yr_2006)
View(yr_2006)

summary(yr_2006)
#Date               Time           Global_active_power Sub_metering_1   Sub_metering_2   Sub_metering_3 
#Length:21992       Length:21992       Min.   :0.194       Min.   : 0.000   Min.   : 0.000   Min.   : 0.00  
#Class :character   Class :character   1st Qu.:0.496       1st Qu.: 0.000   1st Qu.: 0.000   1st Qu.: 0.00  
#Mode  :character   Mode  :character   Median :1.708       Median : 0.000   Median : 0.000   Median : 0.00  
#Mean   :1.901       Mean   : 1.249   Mean   : 2.215   Mean   : 7.41  
#3rd Qu.:2.692       3rd Qu.: 0.000   3rd Qu.: 1.000   3rd Qu.:17.00  
#Max.   :9.132       Max.   :77.000   Max.   :74.000   Max.   :20.00  
 
str(yr_2006)
#str(yr_2006)
#'data.frame':	21992 obs. of  6 variables:
#  $ Date               : chr  "2006-12-16" "2006-12-16" "2006-12-16" "2006-12-16" ...
#$ Time               : chr  "17:24:00" "17:25:00" "17:26:00" "17:27:00" ...
#$ Global_active_power: num  4.22 5.36 5.37 5.39 3.67 ...
#$ Sub_metering_1     : num  0 0 0 0 0 0 0 0 0 0 ...
#$ Sub_metering_2     : num  1 1 2 1 1 2 1 1 1 2 ...
#$ Sub_metering_3     : num  17 16 17 17 17 17 17 17 17 16 ...

head(yr_2006)
#Date     Time Global_active_power Sub_metering_1 Sub_metering_2 Sub_metering_3
#1 2006-12-16 17:24:00               4.216              0              1             17
#2 2006-12-16 17:25:00               5.360              0              1             16
#3 2006-12-16 17:26:00               5.374              0              2             17
#4 2006-12-16 17:27:00               5.388              0              1             17
#5 2006-12-16 17:28:00               3.666              0              1             17
#6 2006-12-16 17:29:00               3.520              0              2             17

tail(yr_2006)
#Date     Time Global_active_power Sub_metering_1 Sub_metering_2 Sub_metering_3
#21987 2006-12-31 23:54:00               2.576              0              0              0
#21988 2006-12-31 23:55:00               2.574              0              0              0
#21989 2006-12-31 23:56:00               2.576              0              0              0
#21990 2006-12-31 23:57:00               2.586              0              0              0
#21991 2006-12-31 23:58:00               2.648              0              0              0
#21992 2006-12-31 23:59:00               2.646              0              0              0


#Refine attributes needed
yr_2006 <- select(yr_2006, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3)
yr_2007 <- select(yr_2007, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3)
yr_2008 <- select(yr_2008, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3) 
yr_2009 <- select(yr_2009, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3)
yr_2010 <- select(yr_2010, Date, Time, Global_active_power, Sub_metering_1, Sub_metering_2, Sub_metering_3) 

final <- bind_rows(yr_2006, yr_2007, yr_2008, yr_2009, yr_2010)
#Combine date & time
final <- cbind(final, paste(final$Date, final$Time), stringsAsFactors = FALSE)
#Change col name
colnames(final)[7] <- "DateTime"

final <- final[,c(ncol(final), 1:(ncol(final)-1))]
## Convert DateTime from character to POSIXct 
final$DateTime <- as.POSIXct(final$DateTime, "%Y/%m/%d %H:%M:%S")
#Warning messages:
#  1: In strptime(xx, f, tz = tz) : unknown timezone '%Y/%m/%d %H:%M:%S'
#2: In as.POSIXct.POSIXlt(x) : unknown timezone '%Y/%m/%d %H:%M:%S'
#3: In strptime(x, f, tz = tz) : unknown timezone '%Y/%m/%d %H:%M:%S'
#4: In as.POSIXct.POSIXlt(as.POSIXlt(x, tz, ...), tz, ...) :
 # unknown timezone '%Y/%m/%d %H:%M:%S'

## Add the time zone
attr(final$DateTime, "tzone") <- "Europe/Paris"



##Create year 
final$Year <- year(final$DateTime)
#Create rest of time frames
final$Quarter <- quarter(final$DateTime)
final$Month <- month(final$DateTime)
final$Week <- week(final$DateTime)
final$Weekdays <- weekdays(final$DateTime)
final$Day <- day(final$DateTime)
final$Hour <- hour(final$DateTime)
final$Minute <- minute(final$DateTime)

colnames(final)[4] <- "Household.Power(kW)"
colnames(final)[5] <- "Kitchen(Wh)" 
colnames(final)[6] <- "Laundry.Room(Wh)" 
colnames(final)[7] <- "Heater.&.A/C(Wh)"

#Remove unneeded
final[,c(2,3)] <- NULL

head(final)
#head(final)
#DateTime Laundry.Room(Wh) Heater.&.A/C(Wh) Year Quarter Month Week Weekdays Day Hour Minute
#1 2006-12-16 18:24:00                1               17 2006       4    12   50 Saturday  16   18     24
#2 2006-12-16 18:25:00                1               16 2006       4    12   50 Saturday  16   18     25
#3 2006-12-16 18:26:00                2               17 2006       4    12   50 Saturday  16   18     26
#4 2006-12-16 18:27:00                1               17 2006       4    12   50 Saturday  16   18     27
#5 2006-12-16 18:28:00                1               17 2006       4    12   50 Saturday  16   18     28
#6 2006-12-16 18:29:00                2               17 2006       4    12   50 Saturday  16   18     29

str(final)
#'data.frame':	2049280 obs. of  11 variables:
 # $ DateTime        : POSIXct, format: "2006-12-16 18:24:00" "2006-12-16 18:25:00" "2006-12-16 18:26:00" "2006-12-16 18:27:00" ...
#$ Laundry.Room(Wh): num  1 1 2 1 1 2 1 1 1 2 ...
#$ Heater.&.A/C(Wh): num  17 16 17 17 17 17 17 17 17 16 ...
#$ Year            : num  2006 2006 2006 2006 2006 ...
#$ Quarter         : int  4 4 4 4 4 4 4 4 4 4 ...
#$ Month           : num  12 12 12 12 12 12 12 12 12 12 ...
#$ Week            : num  50 50 50 50 50 50 50 50 50 50 ...
#$ Weekdays        : chr  "Saturday" "Saturday" "Saturday" "Saturday" ...
#$ Day             : int  16 16 16 16 16 16 16 16 16 16 ...
#$ Hour            : int  18 18 18 18 18 18 18 18 18 18 ...
#$ Minute          : int  24 25 26 27 28 29 30 31 32 33 ...

#Check for missing values 
sum(is.na(final))
#[1] 0

summary(final)
#> summary(final)
#DateTime                   Laundry.Room(Wh) Heater.&.A/C(Wh)      Year         Quarter         Month       
#Min.   :2006-12-16 18:24:00   Min.   : 0.000   Min.   : 0.000   Min.   :2006   Min.   :1.00   Min.   : 1.000  
#1st Qu.:2007-12-10 06:37:45   1st Qu.: 0.000   1st Qu.: 0.000   1st Qu.:2007   1st Qu.:1.00   1st Qu.: 3.000  
#Median :2008-11-30 02:22:30   Median : 0.000   Median : 1.000   Median :2008   Median :2.00   Median : 6.000  
#Mean   :2008-12-02 01:59:44   Mean   : 1.299   Mean   : 6.458   Mean   :2008   Mean   :2.49   Mean   : 6.455  
#3rd Qu.:2009-11-23 21:31:15   3rd Qu.: 1.000   3rd Qu.:17.000   3rd Qu.:2009   3rd Qu.:3.00   3rd Qu.: 9.000  
#Max.   :2010-11-26 22:02:00   Max.   :80.000   Max.   :31.000   Max.   :2010   Max.   :4.00   Max.   :12.000  
#Week         Weekdays              Day             Hour          Minute    
#Min.   : 1.00   Length:2049280     Min.   : 1.00   Min.   : 0.0   Min.   : 0.0  
#1st Qu.:13.00   Class :character   1st Qu.: 8.00   1st Qu.: 5.0   1st Qu.:15.0  
#Median :26.00   Mode  :character   Median :16.00   Median :12.0   Median :30.0  
#Mean   :26.29                      Mean   :15.71   Mean   :11.5   Mean   :29.5  
#3rd Qu.:39.00                      3rd Qu.:23.00   3rd Qu.:18.0   3rd Qu.:45.0  
#Max.   :53.00                      Max.   :31.00   Max.   :23.0   Max.   :59.0  



