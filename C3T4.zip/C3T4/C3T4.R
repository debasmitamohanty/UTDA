



install.packages("tidyverse")
install.packages("openxlsx")
install.packages("knitr")
install.packages("arules")
install.packages("ggplot2", dependencies = TRUE)
install.packages("arulesViz")
install.packages("dplyr")
install.packages("kableExtra")
install.packages("grid")
library(tidyverse)
library(openxlsx)
library(knitr)
library(ggplot2)
library(arules)
library(arulesViz)
library(dplyr)
library(kableExtra)
library(Matrix)
library(lazyeval)
#package for analyzing transactional dat
library(arules)
#package for visualization of arules
library(arulesViz)

##Import data
#Using read transactions bc opencsv will convert to columns, we want basket format
#separator is commas and we are trying to remove duplicates in each column
df_trans<- read.transactions("ElectronidexTransactions2017.csv", format= "basket", sep=",", rm.duplicates = TRUE )

#distribution of transactions with duplicates:
#  items
#1   2 
#191  10

#view transactions
inspect(df_trans)

#Number of transactions___*9835
length(df_trans)
#length(data)
#[1] 9835

#Number of items per transaction
size(df_trans)

#Lists transaction by conversion 
LIST(df_trans)

#Item labels___**125 items
itemLabels(df_trans)

##View Item Frequency
# Plot for the top 20 products with their absolute volume
itemFrequencyPlot(df_trans, type= "absolute", topN =20)
#visualizing item ID, x, up to 125 vs number of transactions for random sample 
image(sample(df_trans,500))

## Mine rules with APRIORI
## Apriori #1
Rules1 <- apriori(df_trans, parameter = list(supp = 0.1, conf = 0.8, minlen = 3)) #Covers 10% of transactions (N=983), 80% correct


#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.8    0.1    1 none FALSE            TRUE       5     0.1      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 983 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.00s].
#sorting and recoding items ... [10 item(s)] done [0.00s].
#creating transaction tree ... done [0.00s].
#checking subsets of size 1 2 done [0.00s].
#writing ... [0 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules1, by='lift')) 

#Apriori 1 generated no rules

## Apriori #2
Rules2 <- apriori(df_trans, parameter = list(supp = 0.01, conf = 0.8, minlen = 3)) 
#Covers 1% of transactions (N=98), 80% correct
Apriori

#Parameter specification:
 # confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.8    0.1    1 none FALSE            TRUE       5    0.01      3     10  rules TRUE

#Algorithmic control:
 # filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 98 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [82 item(s)] done [0.00s].
#creating transaction tree ... done [0.00s].
#checking subsets of size 1 2 3 4 done [0.00s].
#writing ... [0 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules2, by='lift')) 

##Apriori 2 generated no rules, keep going.

## Apriori #3
Rules3 <- apriori(df_trans, parameter = list(supp = 0.005, conf = 0.8, minlen = 3))
#Covers .05% transactions (N=49), 80% correct
#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.8    0.1    1 none FALSE            TRUE       5   0.005      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 49 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [109 item(s)] done [0.00s].
#creating transaction tree ... done [0.01s].
#checking subsets of size 1 2 3 4 5 done [0.00s].
#writing ... [1 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].


inspect(sort(Rules3, by='lift')) 

#lhs                                             rhs         support     confidence coverage   
#[1] {Acer Aspire,Dell Desktop,ViewSonic Monitor} => {HP Laptop} 0.005287239 0.8125     0.006507372
#lift     count
#[1] 4.185928 52  


##Apriori 3 generated 1 rule with a lift = 4

## Apriori #4
Rules4 <- apriori(df_trans, parameter = list(supp = 0.005, conf = 0.7, minlen = 3))
#Covers .05% transactions (N=49), 70% correct
# Rules4 <- apriori(df_trans, parameter = list(supp = 0.005, conf = 0.7, minlen = 3))
#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.7    0.1    1 none FALSE            TRUE       5   0.005      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 49 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [109 item(s)] done [0.00s].
#creating transaction tree ... done [0.01s].
#checking subsets of size 1 2 3 4 5 done [0.01s].
#writing ... [3 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules4, by='lift'))
#lhs                                                      rhs         support     confidence
#[1] {Acer Aspire,Dell Desktop,ViewSonic Monitor}          => {HP Laptop} 0.005287239 0.8125000 
#[2] {ASUS 2 Monitor,Dell Desktop,Lenovo Desktop Computer} => {iMac}      0.005185562 0.7391304 
#[3] {ASUS 2 Monitor,ASUS Monitor}                         => {iMac}      0.005083884 0.7142857 
#coverage    lift     count
#[1] 0.006507372 4.185928 52   
#[2] 0.007015760 2.885807 51   
#[3] 0.007117438 2.788805 50  

##Apriori 4 generated 3 rules, lift = 2.7-4.1

## Apriori #5
Rules5 <- apriori(df_trans, parameter = list(supp = 0.005, conf = 0.6, minlen = 3)) 
#Covers .05% transactions (N=49), 60% correct

#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.6    0.1    1 none FALSE            TRUE       5   0.005      3     10  rules TRUE

#Algorithmic control:
 # filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 49 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [109 item(s)] done [0.00s].
#creating transaction tree ... done [0.01s].
#checking subsets of size 1 2 3 4 5 done [0.01s].
#writing ... [28 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].


inspect(sort(Rules5, by='lift'))

# inspect(sort(Rules5, by='lift'))
#lhs                                                            rhs         support     confidence
#[1]  {Acer Aspire,Dell Desktop,ViewSonic Monitor}                => {HP Laptop} 0.005287239 0.8125000 
#[2]  {Acer Aspire,iMac,ViewSonic Monitor}                        => {HP Laptop} 0.006202339 0.6630435 
#[3]  {Acer Desktop,iMac,ViewSonic Monitor}                       => {HP Laptop} 0.006405694 0.6363636 
#[4]  {Dell Desktop,Lenovo Desktop Computer,ViewSonic Monitor}    => {HP Laptop} 0.006202339 0.6224490 
#[5]  {Computer Game,ViewSonic Monitor}                           => {HP Laptop} 0.007422471 0.6186441 
#[6]  {Computer Game,Dell Desktop}                                => {HP Laptop} 0.005693950 0.6086957 
#[7]  {Acer Aspire,ViewSonic Monitor}                             => {HP Laptop} 0.010777834 0.6022727 
#[8]  {ASUS 2 Monitor,Dell Desktop,Lenovo Desktop Computer}       => {iMac}      0.005185562 0.7391304 
#[9]  {ASUS 2 Monitor,ASUS Monitor}                               => {iMac}      0.005083884 0.7142857 
#[10] {ASUS 2 Monitor,Microsoft Office Home and Student 2016}     => {iMac}      0.005185562 0.6986301

#Apriori 5 generated 28 rules, lift = 2.3-4.8

## Apriori #6
Rules6 <- apriori(df_trans, parameter = list(supp = 0.006, conf = 0.6, minlen = 3)) 
#Covers .06% transactions (N=59), 60% correct

Apriori

#Parameter specification:
 # confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.6    0.1    1 none FALSE            TRUE       5   0.006      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 59 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [102 item(s)] done [0.00s].
#creating transaction tree ... done [0.01s].
#checking subsets of size 1 2 3 4 5 done [0.00s].
#writing ... [17 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules6, by='lift')) 

#[1]  {Acer Aspire,iMac,ViewSonic Monitor}                     => {HP Laptop} 0.006202339 0.6630435 
#[2]  {Acer Desktop,iMac,ViewSonic Monitor}                    => {HP Laptop} 0.006405694 0.6363636 
#[3]  {Dell Desktop,Lenovo Desktop Computer,ViewSonic Monitor} => {HP Laptop} 0.006202339 0.6224490 
#[4]  {Computer Game,ViewSonic Monitor}                        => {HP Laptop} 0.007422471 0.6186441 
#[5]  {Acer Aspire,ViewSonic Monitor}                          => {HP Laptop} 0.010777834 0.6022727 
#[6]  {Dell Desktop,Lenovo Desktop Computer,ViewSonic Monitor} => {iMac}      0.006914082 0.6938776 
#[7]  {Apple Magic Keyboard,ASUS Monitor}                      => {iMac}      0.006812405 0.6700000 
#[8]  {Acer Desktop,HP Laptop,ViewSonic Monitor}               => {iMac}      0.006405694 0.6562500 
#[9]  {Acer Desktop,ASUS 2 Monitor}                            => {iMac}      0.006405694 0.6428571 
#[10] {ASUS Monitor,ViewSonic Monitor}                         => {iMac}      0.008235892 0.6377953 
#[11] {ASUS Monitor,Dell Desktop}                              => {iMac}      0.007930859 0.6341463 
#[12] {Acer Desktop,HP Laptop,Lenovo Desktop Computer}         => {iMac}      0.006304016 0.6326531 
#[13] {ASUS Monitor,Lenovo Desktop Computer}                   => {iMac}      0.009761057 0.6315789 
#[14] {ASUS 2 Monitor,Dell Desktop}                            => {iMac}      0.009049314 0.6312057 

#Apriori 6 generated 17 rules, lift = 2.3-3.1

# Apriori #7
Rules7 <- apriori(df_trans, parameter = list(supp = 0.007, conf = 0.6, minlen = 3))
#Covers .07% transactions (N=68), 60% correct
#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.6    0.1    1 none FALSE            TRUE       5   0.007      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 68 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [97 item(s)] done [0.00s].
#creating transaction tree ... done [0.00s].
#checking subsets of size 1 2 3 4 done [0.00s].
#writing ... [8 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].
inspect(sort(Rules7, by='lift'))

#lhs                                                      rhs         support     confidence
#[1] {Computer Game,ViewSonic Monitor}                     => {HP Laptop} 0.007422471 0.6186441 
#[2] {Acer Aspire,ViewSonic Monitor}                       => {HP Laptop} 0.010777834 0.6022727 
#[3] {ASUS Monitor,ViewSonic Monitor}                      => {iMac}      0.008235892 0.6377953 
#[4] {ASUS Monitor,Dell Desktop}                           => {iMac}      0.007930859 0.6341463 
#[5] {ASUS Monitor,Lenovo Desktop Computer}                => {iMac}      0.009761057 0.6315789 
#[6] {ASUS 2 Monitor,Dell Desktop}                         => {iMac}      0.009049314 0.6312057 
#[7] {HP Laptop,Lenovo Desktop Computer,ViewSonic Monitor} => {iMac}      0.008439248 0.6014493 
#[8] {Dell Desktop,Microsoft Office Home and Student 2016} => {iMac}      0.009456024 0.6000000 
#coverage   lift     count
#[1] 0.01199797 3.187200  73  
#[2] 0.01789527 3.102856 106  
#[3] 0.01291307 2.490161  81  
#[4] 0.01250635 2.475915  78  
#[5] 0.01545501 2.465891  96  
#[6] 0.01433655 2.464433  89  
#[7] 0.01403152 2.348255  83  
#[8] 0.01576004 2.342596  93  

##Apriori 7 generated 8 rules, lift = 2.3-3.1

## Apriori #8
Rules8 <- apriori(df_trans, parameter = list(supp = 0.008, conf = 0.6, minlen = 3)) 
#Covers .08% transactions (N=78), 60% correct

#Apriori

#Parameter specification:
 # confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.6    0.1    1 none FALSE            TRUE       5   0.008      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 78 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [93 item(s)] done [0.00s].
#creating transaction tree ... done [0.00s].
#checking subsets of size 1 2 3 4 done [0.00s].
#writing ... [6 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules8, by='lift')) 
#> inspect(sort(Rules8, by='lift')) 
#lhs                                                      rhs         support     confidence
#[1] {Acer Aspire,ViewSonic Monitor}                       => {HP Laptop} 0.010777834 0.6022727 
#[2] {ASUS Monitor,ViewSonic Monitor}                      => {iMac}      0.008235892 0.6377953 
#[3] {ASUS Monitor,Lenovo Desktop Computer}                => {iMac}      0.009761057 0.6315789 
#[4] {ASUS 2 Monitor,Dell Desktop}                         => {iMac}      0.009049314 0.6312057 
#[5] {HP Laptop,Lenovo Desktop Computer,ViewSonic Monitor} => {iMac}      0.008439248 0.6014493 
#[6] {Dell Desktop,Microsoft Office Home and Student 2016} => {iMac}      0.009456024 0.6000000 
#coverage   lift     count
#[1] 0.01789527 3.102856 106  
#[2] 0.01291307 2.490161  81  
#[3] 0.01545501 2.465891  96  
#[4] 0.01433655 2.464433  89  
#[5] 0.01403152 2.348255  83  
#[6] 0.01576004 2.342596  93

#Apriori 8 generated 6 rules, lift = 2.3-3.1

## Apriori #9
Rules9 <- apriori(df_trans, parameter = list(supp = 0.009, conf = 0.6, minlen = 3)) 
#Covers .09% transactions (N=88), 60% correct

#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.6    0.1    1 none FALSE            TRUE       5   0.009      3     10  rules TRUE

#Algorithmic control:
#  filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 88 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [87 item(s)] done [0.00s].
#creating transaction tree ... done [0.01s].
#checking subsets of size 1 2 3 4 done [0.01s].
#writing ... [4 rule(s)] done [0.00s].
#creating S4 object  ... done [0.01s].

inspect(sort(Rules9, by='lift'))
#nspect(sort(Rules9, by='lift'))
#lhs                                                      rhs         support     confidence
#[1] {Acer Aspire,ViewSonic Monitor}                       => {HP Laptop} 0.010777834 0.6022727 
#[2] {ASUS Monitor,Lenovo Desktop Computer}                => {iMac}      0.009761057 0.6315789 
#[3] {ASUS 2 Monitor,Dell Desktop}                         => {iMac}      0.009049314 0.6312057 
#[4] {Dell Desktop,Microsoft Office Home and Student 2016} => {iMac}      0.009456024 0.6000000 
#coverage   lift     count
#[1] 0.01789527 3.102856 106  
#[2] 0.01545501 2.465891  96  
#[3] 0.01433655 2.464433  89  
#[4] 0.01576004 2.342596  93 

#Apriori 9 generated 6 rules with lift = 1.5-2.2

## Apriori #10
Rules10 <- apriori(df_trans, parameter = list(supp = 0.01, conf = 0.6, minlen = 3))
#Covers 1% transactions (N=98), 60% correct
#Apriori

#Parameter specification:
 # confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.6    0.1    1 none FALSE            TRUE       5    0.01      3     10  rules TRUE

#Algorithmic control:
 # filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 98 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [82 item(s)] done [0.00s].
#creating transaction tree ... done [0.00s].
#checking subsets of size 1 2 3 4 done [0.00s].
#writing ... [1 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules10, by='lift')) 

#lhs                                rhs         support    confidence coverage   lift     count
#[1] {Acer Aspire,ViewSonic Monitor} => {HP Laptop} 0.01077783 0.6022727  0.01789527 3.102856 106  

#Apriori 10 generated 1 rule, lift = 3.1

## Apriori #11
Rules11 <- apriori(df_trans, parameter = list(supp = 0.01, conf = 0.5, minlen = 3)) 
###Covers 1% transactions (N=98), 50% correct

#Apriori

#Parameter specification:
#  confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target  ext
#0.5    0.1    1 none FALSE            TRUE       5    0.01      3     10  rules TRUE

#Algorithmic control:
 # filter tree heap memopt load sort verbose
#0.1 TRUE TRUE  FALSE TRUE    2    TRUE

#Absolute minimum support count: 98 

#set item appearances ...[0 item(s)] done [0.00s].
#set transactions ...[125 item(s), 9835 transaction(s)] done [0.01s].
#sorting and recoding items ... [82 item(s)] done [0.00s].
#creating transaction tree ... done [0.01s].
#checking subsets of size 1 2 3 4 done [0.00s].
#writing ... [19 rule(s)] done [0.00s].
#creating S4 object  ... done [0.00s].

inspect(sort(Rules11[1:10], by='lift'))
#lhs                                                   rhs         support    confidence coverage  
#[1]  {Acer Aspire,ViewSonic Monitor}                    => {HP Laptop} 0.01077783 0.6022727  0.01789527
#[2]  {ASUS 2 Monitor,Lenovo Desktop Computer}           => {iMac}      0.01087951 0.5911602  0.01840366
#[3]  {Apple Magic Keyboard,Dell Desktop}                => {iMac}      0.01016777 0.5847953  0.01738688
#[4]  {ASUS Monitor,HP Laptop}                           => {iMac}      0.01179461 0.5829146  0.02023386
#[5]  {ASUS 2 Monitor,HP Laptop}                         => {iMac}      0.01108287 0.5828877  0.01901373
#[6]  {HP Laptop,Microsoft Office Home and Student 2016} => {iMac}      0.01291307 0.5521739  0.02338587
#[7]  {Acer Desktop,ViewSonic Monitor}                   => {iMac}      0.01006609 0.5439560  0.01850534
#[8]  {Apple Magic Keyboard,Lenovo Desktop Computer}     => {iMac}      0.01138790 0.5161290  0.02206406
#[9]  {Apple Magic Keyboard,HP Laptop}                   => {iMac}      0.01474326 0.5105634  0.02887646
#[10] {HP Laptop,HP Monitor}                             => {iMac}      0.01057448 0.5024155  0.02104728
#lift     count
#[1]  3.102856 106  
#[2]  2.308083 107  
#[3]  2.283232 100  
#[4]  2.275889 116  
#[5]  2.275784 109  
#[6]  2.155868 127  
#[7]  2.123782  99  
#[8]  2.015137 112  
#[9]  1.993406 145  
#[10] 1.961594 104  


#Apriori 11 generated 19 total association rules, lift = 1.9-3.1. 
#This appears to be our best rule, because it generated 19 total rules, 
#has a good amount of support (1% frequency), confidence (50% accuracy), 
#and lift of 1.5-3.1 (>1 indicates effectiveness).
#We will further inspect support, confidence, and lift to confirm.

# inspect support
support11 <- data.frame(inspect(sort(Rules11, by = 'support', decreasing = TRUE)))
#Dell desktop and ViewSonic Monitor (#2) had greatest support at 1.5% (n=150 count)

#support11 <- data.frame(inspect(sort(Rules11, by = 'support', decreasing = TRUE)))
#lhs                                                   rhs         support    confidence coverage  
#[1]  {HP Laptop,Lenovo Desktop Computer}                => {iMac}      0.02308083 0.5000000  0.04616167
#[2]  {Dell Desktop,Lenovo Desktop Computer}             => {iMac}      0.01860702 0.5069252  0.03670564
#[3]  {Acer Desktop,HP Laptop}                           => {iMac}      0.01596340 0.5114007  0.03121505
#[4]  {Lenovo Desktop Computer,ViewSonic Monitor}        => {iMac}      0.01576004 0.5555556  0.02836807
#[5]  {Dell Desktop,ViewSonic Monitor}                   => {HP Laptop} 0.01525165 0.5747126  0.02653787
#[6]  {Apple Magic Keyboard,HP Laptop}                   => {iMac}      0.01474326 0.5105634  0.02887646
#[7]  {Dell Desktop,ViewSonic Monitor}                   => {iMac}      0.01474326 0.5555556  0.02653787
#[8]  {HP Laptop,Microsoft Office Home and Student 2016} => {iMac}      0.01291307 0.5521739  0.02338587
#[9]  {CYBERPOWER Gamer Desktop,ViewSonic Monitor}       => {iMac}      0.01281139 0.5271967  0.02430097
#[10] {Acer Desktop,Lenovo Desktop Computer}             => {iMac}      0.01230300 0.5307018  0.02318251
#[11] {CYBERPOWER Gamer Desktop,ViewSonic Monitor}       => {HP Laptop} 0.01220132 0.5020921  0.02430097
#[12] {ASUS Monitor,HP Laptop}                           => {iMac}      0.01179461 0.5829146  0.02023386
#[13] {Apple Magic Keyboard,Lenovo Desktop Computer}     => {iMac}      0.01138790 0.5161290  0.02206406
#[14] {ASUS 2 Monitor,HP Laptop}                         => {iMac}      0.01108287 0.5828877  0.01901373
#[15] {ASUS 2 Monitor,Lenovo Desktop Computer}           => {iMac}      0.01087951 0.5911602  0.01840366
#[16] {Acer Aspire,ViewSonic Monitor}                    => {HP Laptop} 0.01077783 0.6022727  0.01789527
#[17] {HP Laptop,HP Monitor}                             => {iMac}      0.01057448 0.5024155  0.02104728
#[18] {Apple Magic Keyboard,Dell Desktop}                => {iMac}      0.01016777 0.5847953  0.01738688
#[19] {Acer Desktop,ViewSonic Monitor}                   => {iMac}      0.01006609 0.5439560  0.01850534
#lift     count
#[1]  1.952164 227  
#[2]  1.979202 183  
#[3]  1.996675 157  
#[4]  2.169071 155  
#[5]  2.960869 150  
#[6]  1.993406 145  
#[7]  2.169071 145  
#[8]  2.155868 127  
#[9]  2.058348 126  
#[10] 2.072033 121  
#[11] 2.586734 120  
#[12] 2.275889 116  
#[13] 2.015137 112  
#[14] 2.275784 109  
#[15] 2.308083 107  
#[16] 3.102856 106  
#[17] 1.961594 104  
#[18] 2.283232 100  
#[19] 2.123782  99 

support11

#> support11
#lhs Var.2         rhs    support confidence
#[1]                 {HP Laptop,Lenovo Desktop Computer}    =>      {iMac} 0.02308083  0.5000000
#[2]              {Dell Desktop,Lenovo Desktop Computer}    =>      {iMac} 0.01860702  0.5069252
#[3]                            {Acer Desktop,HP Laptop}    =>      {iMac} 0.01596340  0.5114007
#[4]         {Lenovo Desktop Computer,ViewSonic Monitor}    =>      {iMac} 0.01576004  0.5555556
#[5]                    {Dell Desktop,ViewSonic Monitor}    => {HP Laptop} 0.01525165  0.5747126
#[6]                    {Apple Magic Keyboard,HP Laptop}    =>      {iMac} 0.01474326  0.5105634
#[7]                    {Dell Desktop,ViewSonic Monitor}    =>      {iMac} 0.01474326  0.5555556
#[8]  {HP Laptop,Microsoft Office Home and Student 2016}    =>      {iMac} 0.01291307  0.5521739
#[9]        {CYBERPOWER Gamer Desktop,ViewSonic Monitor}    =>      {iMac} 0.01281139  0.5271967
#[10]             {Acer Desktop,Lenovo Desktop Computer}    =>      {iMac} 0.01230300  0.5307018
#[11]       {CYBERPOWER Gamer Desktop,ViewSonic Monitor}    => {HP Laptop} 0.01220132  0.5020921
#[12]                           {ASUS Monitor,HP Laptop}    =>      {iMac} 0.01179461  0.5829146
#[13]     {Apple Magic Keyboard,Lenovo Desktop Computer}    =>      {iMac} 0.01138790  0.5161290
#[14]                         {ASUS 2 Monitor,HP Laptop}    =>      {iMac} 0.01108287  0.5828877
#[15]           {ASUS 2 Monitor,Lenovo Desktop Computer}    =>      {iMac} 0.01087951  0.5911602
#[16]                    {Acer Aspire,ViewSonic Monitor}    => {HP Laptop} 0.01077783  0.6022727
#[17]                             {HP Laptop,HP Monitor}    =>      {iMac} 0.01057448  0.5024155
#[18]                {Apple Magic Keyboard,Dell Desktop}    =>      {iMac} 0.01016777  0.5847953
#[19]                   {Acer Desktop,ViewSonic Monitor}    =>      {iMac} 0.01006609  0.5439560
#coverage     lift count
#[1]  0.04616167 1.952164   227
#[2]  0.03670564 1.979202   183
#[3]  0.03121505 1.996675   157
#[4]  0.02836807 2.169071   155
#[5]  0.02653787 2.960869   150
#[6]  0.02887646 1.993406   145
#[7]  0.02653787 2.169071   145
#[8]  0.02338587 2.155868   127
#[9]  0.02430097 2.058348   126

## data frame with 0 columns and 0 rows

# inspect confidence
confidence11 <- data.frame(inspect(sort(Rules11, by = 'confidence', decreasing = TRUE)))
#Acer Aspire and ViewSonic Monitor (#1) had greatest confidence at 60% (although 2nd rule 57%)

#lhs                                                   rhs         support    confidence coverage  
#[1]  {Acer Aspire,ViewSonic Monitor}                    => {HP Laptop} 0.01077783 0.6022727  0.01789527
#[2]  {ASUS 2 Monitor,Lenovo Desktop Computer}           => {iMac}      0.01087951 0.5911602  0.01840366
#[3]  {Apple Magic Keyboard,Dell Desktop}                => {iMac}      0.01016777 0.5847953  0.01738688
#[4]  {ASUS Monitor,HP Laptop}                           => {iMac}      0.01179461 0.5829146  0.02023386
#[5]  {ASUS 2 Monitor,HP Laptop}                         => {iMac}      0.01108287 0.5828877  0.01901373
#[6]  {Dell Desktop,ViewSonic Monitor}                   => {HP Laptop} 0.01525165 0.5747126  0.02653787
#[7]  {Dell Desktop,ViewSonic Monitor}                   => {iMac}      0.01474326 0.5555556  0.02653787
#[8]  {Lenovo Desktop Computer,ViewSonic Monitor}        => {iMac}      0.01576004 0.5555556  0.02836807
#[9]  {HP Laptop,Microsoft Office Home and Student 2016} => {iMac}      0.01291307 0.5521739  0.02338587
#[10] {Acer Desktop,ViewSonic Monitor}                   => {iMac}      0.01006609 0.5439560  0.01850534
#[11] {Acer Desktop,Lenovo Desktop Computer}             => {iMac}      0.01230300 0.5307018  0.02318251
#[12] {CYBERPOWER Gamer Desktop,ViewSonic Monitor}       => {iMac}      0.01281139 0.5271967  0.02430097
#[13] {Apple Magic Keyboard,Lenovo Desktop Computer}     => {iMac}      0.01138790 0.5161290  0.02206406
#[14] {Acer Desktop,HP Laptop}                           => {iMac}      0.01596340 0.5114007  0.03121505
#[15] {Apple Magic Keyboard,HP Laptop}                   => {iMac}      0.01474326 0.5105634  0.02887646
#[16] {Dell Desktop,Lenovo Desktop Computer}             => {iMac}      0.01860702 0.5069252  0.03670564
#[17] {HP Laptop,HP Monitor}                             => {iMac}      0.01057448 0.5024155  0.02104728
#[18] {CYBERPOWER Gamer Desktop,ViewSonic Monitor}       => {HP Laptop} 0.01220132 0.5020921  0.02430097
#[19] {HP Laptop,Lenovo Desktop Computer}                => {iMac}      0.02308083 0.5000000  0.04616167
#lift     count
#[1]  3.102856 106  
#[2]  2.308083 107  

confidence11

# confidence11
#lhs Var.2         rhs    support confidence
#[1]                     {Acer Aspire,ViewSonic Monitor}    => {HP Laptop} 0.01077783  0.6022727
#[2]            {ASUS 2 Monitor,Lenovo Desktop Computer}    =>      {iMac} 0.01087951  0.5911602
#[3]                 {Apple Magic Keyboard,Dell Desktop}    =>      {iMac} 0.01016777  0.5847953
#[4]                            {ASUS Monitor,HP Laptop}    =>      {iMac} 0.01179461  0.5829146
#[5]                          {ASUS 2 Monitor,HP Laptop}    =>      {iMac} 0.01108287  0.5828877
#[6]                    {Dell Desktop,ViewSonic Monitor}    => {HP Laptop} 0.01525165  0.5747126
#[7]                    {Dell Desktop,ViewSonic Monitor}    =>      {iMac} 0.01474326  0.5555556
#[8]         {Lenovo Desktop Computer,ViewSonic Monitor}    =>      {iMac} 0.01576004  0.5555556
#[9]  {HP Laptop,Microsoft Office Home and Student 2016}    =>      {iMac} 0.01291307  0.5521739
#[10]                   {Acer Desktop,ViewSonic Monitor}    =>      {iMac} 0.01006609  0.5439560
#[11]             {Acer Desktop,Lenovo Desktop Computer}    =>      {iMac} 0.01230300  0.5307018
#[12]       {CYBERPOWER Gamer Desktop,ViewSonic Monitor}    =>      {iMac} 0.01281139  0.5271967
#[13]     {Apple Magic Keyboard,Lenovo Desktop Computer}    =>      {iMac} 0.01138790  0.5161290
#[14]                           {Acer Desktop,HP Laptop}    =>      {iMac} 0.01596340  0.5114007
#[15]                   {Apple Magic Keyboard,HP Laptop}    =>      {iMac} 0.01474326  0.5105634
#[16]             {Dell Desktop,Lenovo Desktop Computer}    =>      {iMac} 0.01860702  0.5069252
#[17]                             {HP Laptop,HP Monitor}    =>      {iMac} 0.01057448  0.5024155
#[18]       {CYBERPOWER Gamer Desktop,ViewSonic Monitor}    => {HP Laptop} 0.01220132  0.5020921
#[19]                {HP Laptop,Lenovo Desktop Computer}    =>      {iMac} 0.02308083  0.5000000
#coverage     lift count
#[1]  0.01789527 3.102856   106
#[2]  0.01840366 2.308083   107
#[3]  0.01738688 2.283232   100
#[4]  0.02023386 2.275889   116
#[5]  0.01901373 2.275784   109
#[6]  0.02653787 2.960869   150
#[7]  0.02653787 2.169071   145
#[8]  0.02836807 2.169071   155
#[9]  0.02338587 2.155868   127

## data frame with 0 columns and 0 rows

# inspect lift
lift11 <- data.frame(inspect(sort(Rules11, by = 'lift', decreasing = TRUE)))
#lhs                                                   rhs         support    confidence coverage  
#[1]  {Acer Aspire,ViewSonic Monitor}                    => {HP Laptop} 0.01077783 0.6022727  0.01789527
#[2]  {Dell Desktop,ViewSonic Monitor}                   => {HP Laptop} 0.01525165 0.5747126  0.02653787
#[3]  {CYBERPOWER Gamer Desktop,ViewSonic Monitor}       => {HP Laptop} 0.01220132 0.5020921  0.02430097
#[4]  {ASUS 2 Monitor,Lenovo Desktop Computer}           => {iMac}      0.01087951 0.5911602  0.01840366
#[5]  {Apple Magic Keyboard,Dell Desktop}                => {iMac}      0.01016777 0.5847953  0.01738688
#[6]  {ASUS Monitor,HP Laptop}                           => {iMac}      0.01179461 0.5829146  0.02023386
#[7]  {ASUS 2 Monitor,HP Laptop}                         => {iMac}      0.01108287 0.5828877  0.01901373
#[8]  {Dell Desktop,ViewSonic Monitor}                   => {iMac}      0.01474326 0.5555556  0.02653787
#[9]  {Lenovo Desktop Computer,ViewSonic Monitor}        => {iMac}      0.01576004 0.5555556  0.02836807
#[10] {HP Laptop,Microsoft Office Home and Student 2016} => {iMac}      0.01291307 0.5521739  0.02338587
#[11] {Acer Desktop,ViewSonic Monitor}                   => {iMac}      0.01006609 0.5439560  0.01850534
#[12] {Acer Desktop,Lenovo Desktop Computer}             => {iMac}      0.01230300 0.5307018  0.02318251
#[13] {CYBERPOWER Gamer Desktop,ViewSonic Monitor}       => {iMac}      0.01281139 0.5271967  0.02430097
#[14] {Apple Magic Keyboard,Lenovo Desktop Computer}     => {iMac}      0.01138790 0.5161290  0.02206406
#[15] {Acer Desktop,HP Laptop}                           => {iMac}      0.01596340 0.5114007  0.03121505
#[16] {Apple Magic Keyboard,HP Laptop}                   => {iMac}      0.01474326 0.5105634  0.02887646
#[17] {Dell Desktop,Lenovo Desktop Computer}             => {iMac}      0.01860702 0.5069252  0.03670564
#[18] {HP Laptop,HP Monitor}                             => {iMac}      0.01057448 0.5024155  0.02104728
#[19] {HP Laptop,Lenovo Desktop Computer}                => {iMac}      0.02308083 0.5000000  0.04616167
#lift     count
#[1]  3.102856 106  
#[2]  2.960869 150  
#[3]  2.586734 120  
#[4]  2.308083 107  
#[5]  2.283232 100  
#[6]  2.275889 116  
#[7]  2.275784 109  
#[8]  2.169071 14

lift11
#lhs Var.2         rhs    support confidence
#[1]                     {Acer Aspire,ViewSonic Monitor}    => {HP Laptop} 0.01077783  0.6022727
#[2]                    {Dell Desktop,ViewSonic Monitor}    => {HP Laptop} 0.01525165  0.5747126
#[3]        {CYBERPOWER Gamer Desktop,ViewSonic Monitor}    => {HP Laptop} 0.01220132  0.5020921
#[4]            {ASUS 2 Monitor,Lenovo Desktop Computer}    =>      {iMac} 0.01087951  0.5911602
#[5]                 {Apple Magic Keyboard,Dell Desktop}    =>      {iMac} 0.01016777  0.5847953
#[6]                            {ASUS Monitor,HP Laptop}    =>      {iMac} 0.01179461  0.5829146
#[7]                          {ASUS 2 Monitor,HP Laptop}    =>      {iMac} 0.01108287  0.5828877
#[8]                    {Dell Desktop,ViewSonic Monitor}    =>      {iMac} 0.01474326  0.5555556
#[9]         {Lenovo Desktop Computer,ViewSonic Monitor}    =>      {iMac} 0.01576004  0.5555556
#[10] {HP Laptop,Microsoft Office Home and Student 2016}    =>      {iMac} 0.01291307  0.5521739
#[11]                   {Acer Desktop,ViewSonic Monitor}    =>      {iMac} 0.01006609  0.5439560
#[12]             {Acer Desktop,Lenovo Desktop Computer}    =>      {iMac} 0.01230300  0.5307018
#[13]       {CYBERPOWER Gamer Desktop,ViewSonic Monitor}    =>      {iMac} 0.01281139  0.5271967
#[14]     {Apple Magic Keyboard,Lenovo Desktop Computer}    =>      {iMac} 0.01138790  0.5161290
#[15]                           {Acer Desktop,HP Laptop}    =>      {iMac} 0.01596340  0.5114007
#[16]                   {Apple Magic Keyboard,HP Laptop}    =>      {iMac} 0.01474326  0.5105634
#[17]             {Dell Desktop,Lenovo Desktop Computer}    =>      {iMac} 0.01860702  0.5069252
#[18]                             {HP Laptop,HP Monitor}    =>      {iMac} 0.01057448  0.5024155
#[19]                {HP Laptop,Lenovo Desktop Computer}    =>      {iMac} 0.02308083  0.5000000
#coverage     lift count
#[1]  0.01789527 3.102856   106
#[2]  0.02653787 2.960869   150
#[3]  0.02430097 2.586734   120
#[4]  0.01840366 2.308083   107
#[5]  0.01738688 2.283232   100
#[6]  0.02023386 2.275889   116
#[7]  0.01901373 2.275784   109
#[8]  0.02653787 2.169071   145
## data frame with 0 columns and 0 rows
# check quality for rules 11
head(quality(Rules11))
#support confidence   coverage     lift count
#1 0.01087951  0.5911602 0.01840366 2.308083   107
#2 0.01108287  0.5828877 0.01901373 2.275784   109
#3 0.01179461  0.5829146 0.02023386 2.275889   116
#4 0.01291307  0.5521739 0.02338587 2.155868   127
#5 0.01057448  0.5024155 0.02104728 1.961594   104
#6 0.01016777  0.5847953 0.01738688 2.283232   100

# check for redundancy
inspect(Rules11[is.redundant(Rules11)]) #No redundant rules

###plot best set of rules (11)
plot(Rules11)

plot(Rules11, method = 'graph')

##Summarize best set of rules (11)
summary(Rules11)

#set of 19 rules

#rule length distribution (lhs + rhs):sizes
#3 
#19 

#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#3       3       3       3       3       3 

#summary of quality measures:
 # support          confidence        coverage            lift           count      
#Min.   :0.01007   Min.   :0.5000   Min.   :0.01739   Min.   :1.952   Min.   : 99.0  
#1st Qu.:0.01098   1st Qu.:0.5110   1st Qu.:0.01962   1st Qu.:2.006   1st Qu.:108.0  
#Median :0.01230   Median :0.5440   Median :0.02339   Median :2.156   Median :121.0  
#Mean   :0.01343   Mean   :0.5439   Mean   :0.02495   Mean   :2.234   Mean   :132.1  
#3rd Qu.:0.01500   3rd Qu.:0.5788   3rd Qu.:0.02745   3rd Qu.:2.280   3rd Qu.:147.5  
#Max.   :0.02308   Max.   :0.6023   Max.   :0.04616   Max.   :3.103   Max.   :227.0  

#mining info:
#  data ntransactions support confidence
#df_trans          9835    0.01        0.5


